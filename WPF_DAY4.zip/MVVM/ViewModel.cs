﻿using System.Windows.Input;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.ComponentModel;
using MVVM;

namespace MvvmSample.Wpf
{
    public class ViewModel : ObservableObject
    {
        public readonly Model _model;

        public ViewModel()
        {
            _model = new Model();

            ResetCommand = new RelayCommand(Reset);
            IncreaseCommand = new RelayCommand(Increase);
        }

        public int Data
        {
            get => _model.Data;
            set => SetProperty(_model.Data, value, _model, (u, n) => u.Data = n);
        }

        private void Increase()
        {
            Data++;
        }

        private void Reset()
        {
            Data = 0;
        }

        public ICommand ResetCommand { get; }
        public ICommand IncreaseCommand { get; }
    }
}