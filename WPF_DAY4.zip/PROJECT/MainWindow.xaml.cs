﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROJECT
{
    public partial class MainWindow : Window
    {
        private Person p1 = new Person { Name = "kim", Address = "seoul" };
        private Person p2 = new Person { Name = "lee", Address = "jeju" };

        private ObservableCollection<Person> col = new ObservableCollection<Person>();

        public MainWindow()
        {
            InitializeComponent();

            col.Add(new Person { Name = "김영희", Address = "서울" });
            col.Add(new Person { Name = "이철수", Address = "부산" });
            col.Add(new Person { Name = "최준수", Address = "경기" });

            listbox.ItemsSource = col;
            stackpanel.DataContext = col[0];
        }

        private void listbox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int idx = listbox.SelectedIndex;


            stackpanel.DataContext = col[idx];
        }

        private void CommandBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            col.Add(new Person { Name = txtName.Text, Address = txtAddress.Text });

            txtName.Text = "";
            txtAddress.Text = "";
        }

        private void CommandBinding_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = !string.IsNullOrEmpty(txtName.Text) && !string.IsNullOrEmpty(txtAddress.Text);
        }

        private void txtName_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {

            if (short.TryParse(e.Text, out short value))
                e.Handled = true;

           

        }

        private void ExitMenu(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void AboutMenu(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("제출자 이름을 나타나게 해주세요");
        }
    }
}