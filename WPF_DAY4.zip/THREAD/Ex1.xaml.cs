﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace THREAD
{
    /// <summary>
    /// Ex1.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Ex1 : Window
    {
        public Ex1()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
//            Foo();

              Thread t = new Thread(Foo);
              t.Start();            
        }

        private void Foo()
        {
            for(int i = 0; i < 100; i++)
            {
//              Console.WriteLine($"Foo {i}");
                Thread.Sleep(100);
                //              pgbar.Value = i;

                //                DispatcherOperation dispatcherOperation = Dispatcher.BeginInvoke(
                //                        DispatcherPriority.Normal, new Action<int>( (v) => { this.pgbar.Value = v; }), i);

                Action<int> act = (v) => { this.pgbar.Value = v; };

                DispatcherOperation dispatcherOperation = Dispatcher.BeginInvoke( DispatcherPriority.Normal, act, i);
            }
        }
    }
}
