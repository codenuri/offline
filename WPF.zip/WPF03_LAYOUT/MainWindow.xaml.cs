﻿using LAYOUT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF03_LAYOUT
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void btn1_click(object sender, RoutedEventArgs e)
        {
            Ex2_StackPanel win = new Ex2_StackPanel();
            win.ShowDialog();
        }
        private void btn2_click(object sender, RoutedEventArgs e)
        {
            Ex3_DockPanel win = new Ex3_DockPanel();
            win.ShowDialog();
        }
        private void btn3_click(object sender, RoutedEventArgs e)
        {
            Ex4_Example1 win = new Ex4_Example1();
            win.ShowDialog();
        }
        private void btn4_click(object sender, RoutedEventArgs e)
        {
            Ex5_WrapPanel win = new Ex5_WrapPanel();
            win.ShowDialog();
        }
        private void btn5_click(object sender, RoutedEventArgs e)
        {
            Ex6_Grid win = new Ex6_Grid();
            win.ShowDialog();
        }
        private void btn6_click(object sender, RoutedEventArgs e)
        {
            Ex7_GridSplitter win = new Ex7_GridSplitter();
            win.ShowDialog();
        }
        private void btn7_click(object sender, RoutedEventArgs e)
        {
            Ex8_GridSplitter2 win = new Ex8_GridSplitter2();
            win.ShowDialog();
        }
        private void btn8_click(object sender, RoutedEventArgs e)
        {
            Ex9_Example2 win = new Ex9_Example2();
            win.ShowDialog();
        }
        private void btn9_click(object sender, RoutedEventArgs e)
        {
            App app = (App)Application.Current;
            app.Shutdown();
        }
    }
}