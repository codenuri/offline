﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_PUZZLEGAME
{
    public partial class MainWindow : Window
    {
        // Step 1.
        private const int COUNT = 5;
        private const int EMPTY = COUNT * COUNT - 1;

        public void MakeBoardGrid()
        {
            for (int i = 0; i < COUNT; i++)
            {
                RowDefinition row = new RowDefinition();
                Board.RowDefinitions.Add(row);
            }
            for (int i = 0; i < COUNT; i++)
            {
                ColumnDefinition col = new ColumnDefinition();
                Board.ColumnDefinitions.Add(col);
            }
        }
        // Step2. 
        private int[,] state = new int[COUNT,COUNT];

        public void InitState()
        {
            for (int y = 0; y < COUNT; y++)
            {
                for (int x = 0; x < COUNT; x++)
                {
                    state[y, x] = y * COUNT + x;
                }
            }
        }


        // Step3. ImageLoad
        private double width = 0;
        private double height = 0;


        public void InitBoardImage()
        {
            BitmapImage bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.UriSource = new Uri("B:\\totoro.jpg");
            bitmap.EndInit();

            width  = (bitmap.Width) / COUNT;
            height = (bitmap.Height) / COUNT;

            for(int y = 0; y < COUNT; y++)
            {
                for (int x = 0; x < COUNT; x++)
                {
                    if (state[y, x] != EMPTY)
                    {
                        int bx = state[y, x] % COUNT;
                        int by = state[y, x] / COUNT;

                        CroppedBitmap cb = new CroppedBitmap(bitmap, new Int32Rect((int)(bx * width), (int)(by * height), (int)width, (int)height));

                        Image img = new Image();
                        img.Source = cb;
                        img.Stretch = Stretch.Fill;
                        img.Margin = new Thickness(0.5);

                        Grid.SetRow(img, y);
                        Grid.SetColumn(img, x);

                        Board.Children.Add(img);
                    }
                }
            }
        }

        // Step4. MouseClick
        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);

            Point pt = e.GetPosition(Board);

          

//          Console.WriteLine($"{Board.ActualWidth}, {Board.ActualHeight}");

            int bx = (int)(pt.X / (Board.ActualWidth / COUNT));
            int by = (int)(pt.Y / (Board.ActualHeight / COUNT));

            Console.WriteLine($"{bx}, {by}");

            if ( bx < 0 || bx >= COUNT || by < 0 || by >= COUNT)
                return;

            if ( bx < COUNT-1 && state[by, bx+1] == EMPTY) // RIGHT 가 empty
            {                
                int temp = state[by, bx + 1];
                state[by, bx + 1] = state[by, bx];
                state[by, bx] = temp;

                SwapImage(bx, by, bx + 1, by);
            }
            else if (bx > 0 && state[by, bx - 1] == EMPTY) // Left 가 empty
            {
                int temp = state[by, bx - 1];
                state[by, bx - 1] = state[by, bx];
                state[by, bx] = temp;

                SwapImage(bx, by, bx - 1, by);
            }
            else if (by < COUNT - 1 && state[by + 1, bx] == EMPTY) 
            {
                int temp = state[by + 1, bx];
                state[by+1, bx] = state[by, bx];
                state[by, bx] = temp;

                SwapImage(bx, by, bx, by + 1);
            }
            else if (by > 0 && state[by-1, bx] == EMPTY)
            {
                int temp = state[by-1, bx];
                state[by-1, bx] = state[by, bx];
                state[by, bx] = temp;

                SwapImage(bx, by, bx, by-1);
            }
            else
            {
                SystemSounds.Beep.Play();
                return;
            }
            
            // 다 맞춰었는지 확인
        }

        // Step 5. SwapImage
        public void SwapImage(int x1, int y1, int x2, int y2)
        {
            Image img1 = Board.Children.Cast<Image>().FirstOrDefault(uie => Grid.GetRow(uie) == y1 && Grid.GetColumn(uie) == x1);
            Image img2 = Board.Children.Cast<Image>().FirstOrDefault(uie => Grid.GetRow(uie) == y2 && Grid.GetColumn(uie) == x2);

            if (img1 != null)
            {
                Console.WriteLine("img1 null");
                Grid.SetRow(img1, y2);
                Grid.SetColumn(img1, x2);
            }

            if (img2 != null)
            {
                Console.WriteLine("img2 null");
                Grid.SetRow(img2, y1);
                Grid.SetColumn(img2, x1);
            }

            Board.InvalidateVisual();
        }


        public MainWindow()
        {
            InitializeComponent();
            MakeBoardGrid();
            InitState();
            InitBoardImage();
        }

        private void btnShuffle_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
