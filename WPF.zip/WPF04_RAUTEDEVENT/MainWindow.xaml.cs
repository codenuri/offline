﻿using RAUTEDEVENT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF04_RAUTEDEVENT
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn1_click(object sender, RoutedEventArgs e)
        {
            Ex1_ButtonEvent win = new Ex1_ButtonEvent();
            win.ShowDialog();
        }
        private void btn2_click(object sender, RoutedEventArgs e)
        {
            Ex1_RautedEvent win = new Ex1_RautedEvent();
            win.ShowDialog();
        }
        private void btn3_click(object sender, RoutedEventArgs e)
        {
            Ex2_KeyPressEvent win = new Ex2_KeyPressEvent();
            win.ShowDialog();
        }
        private void btn4_click(object sender, RoutedEventArgs e)
        {
            Ex3_NumTextBox win = new Ex3_NumTextBox();
            win.ShowDialog();
        }
        private void btn5_click(object sender, RoutedEventArgs e)
        {
            Ex4_AddHandler win = new Ex4_AddHandler();
            win.ShowDialog();
        }
    }
}
