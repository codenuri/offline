﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RAUTEDEVENT
{
    /// <summary>
    /// Ex1_RautedEvent.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Ex1_RautedEvent : Window
    {
        public Ex1_RautedEvent()
        {
            InitializeComponent();
        }

        private void Label_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Point p = e.GetPosition(sender as Window);

            Console.WriteLine($"Label_MouseDown {p.X} {p.Y}");
        }
        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Point p = e.GetPosition(sender as Window);

            Console.WriteLine($"Grid_MouseDown {p.X} {p.Y}");
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Point p = e.GetPosition(sender as Window);
            Console.WriteLine($"Window_MouseDown {p.X} {p.Y}");
        }

        private void Window_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Point p = e.GetPosition(sender as Window);

            Console.WriteLine($"Window_PreviewMouseDown {p.X} {p.Y}");
        }
 
        private void Grid_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Point p = e.GetPosition(sender as Window);

            Console.WriteLine($"Grid_PreviewMouseDown  {p.X} {p.Y}");
        }

        private void Label_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Point p = e.GetPosition(sender as Window);

            Console.WriteLine($"Label_PreviewMouseDown  {p.X} {p.Y}");
        }


    }
}

