﻿// Step21. windows propertys
// 핵심 1. 스패너 아이콘
// 핵심 2. 다양한 property 를 알아 둘것

using System;
using System.Windows;
using System.Windows.Media; // SolidColorBrush

public class Program
{
    [STAThread]
    public static void Main()
    {
        Application app = new Application();

        Window win = new Window();

        win.Width = 500;
        win.Height = 500;
        win.Title = "WPF";
        win.Topmost = true;
        win.Background = new SolidColorBrush(Colors.Yellow);

        app.Run(win);
    }
}
