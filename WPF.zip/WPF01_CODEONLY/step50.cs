﻿// Step50. App, MainWindow 클래스 기본 코드

using System;
using System.Windows;
using System.Windows.Input;

public class MainWindow : System.Windows.Window
{
    public MainWindow()
    {
    }
}

public class App : System.Windows.Application
{
    [STAThread]
    public static void Main()
    {
        App app = new App();

        app.Run(new MainWindow());
    }
}

