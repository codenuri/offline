﻿// Step61. Grid Layout

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

public class MainWindow : System.Windows.Window
{
    private Button btn1 = null;
    private Button btn2 = null;
    private Grid grid = null;

    public MainWindow()
    {
        grid = new Grid();
        grid.RowDefinitions.Add(new RowDefinition());
        grid.RowDefinitions.Add(new RowDefinition());

        this.Content = grid;

        btn1 = new Button();
        btn1.Content = "확인1";
        Grid.SetRow(btn1, 0);

        btn2 = new Button();
        btn2.Content = "확인2";
        Grid.SetRow(btn2, 1);

        grid.Children.Add(btn1);
        grid.Children.Add(btn2);
    }
}

public class App : System.Windows.Application
{
    [STAThread]
    public static void Main()
    {
        App app = new App();
        app.Run(new MainWindow());
    }
}

