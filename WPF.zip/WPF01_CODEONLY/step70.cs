﻿// 1. step70.xaml 추가
// 2. using System.Windows.Markup;
// 3. System.xml 추가

using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

public class MainWindow : System.Windows.Window
{
    protected void InitializeComponent()
    {
        Grid grid;

        using (FileStream fs = new FileStream("../../step70.xaml", FileMode.Open))
        {
            grid = (Grid)XamlReader.Load(fs);
        }
        // Windows 에 grid 연결
        this.Content = grid;

        Button btn1 = (Button)grid.FindName("button1");
        btn1.Click += button1_click;
    }

    public MainWindow()
    {
        InitializeComponent();
    }
    private void button1_click(object sender, RoutedEventArgs e)
    {
        Button btn = sender as Button;
        string s1 = btn.Content as string;
        Console.WriteLine($"Click , {s1}");
    }
}

public class App : System.Windows.Application
{
    [STAThread]
    public static void Main()
    {
        App app = new App();
        app.Run(new MainWindow());
    }
}

