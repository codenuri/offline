﻿// Step30. Application 객체의 Event 처리 방법
// 핵심 1. delegate 사용한 이벤트 처리 기술


using System;
using System.Windows;

public class Program
{
    public static void AppStartup(object sender, StartupEventArgs e)
    {
        Console.WriteLine("AppStartup");
    }
    public static void AppExit(object sender, ExitEventArgs e)
    {
        Console.WriteLine("AppExit");
    }
    public static void WindowActivate(object sender, EventArgs e)
    {
        Console.WriteLine("WindowActivate");
    }

    [STAThread]
    public static void Main()
    {
        Application app = new Application();

        app.Startup += AppStartup;
        app.Exit += AppExit;
        app.Activated += WindowActivate;

        app.Run(new Window() );
    }

}
