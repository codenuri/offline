﻿// Step60. Layout 의 필요성

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

public class MainWindow : System.Windows.Window
{
    private Button btn1 = null;

    public MainWindow()
    {
        btn1 = new Button();
        btn1.Content = "확인";
        this.Content = btn1;

        // button event 처리
        btn1.Click += OnButton1_Click;
    }
    private void OnButton1_Click(object sender, RoutedEventArgs e)
    {
        Button btn = sender as Button;
        string s1 = btn.Content as string;
        Console.WriteLine($"Click , {s1}");
    }
}

public class App : System.Windows.Application
{
    [STAThread]
    public static void Main()
    {
        App app = new App();
        app.Run(new MainWindow());
    }
}

