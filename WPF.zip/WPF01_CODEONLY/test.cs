﻿
using System;
using System.Windows;

public class Program
{
    [STAThread]
    public static void Main()
    {
        Application app = new Application();
        Console.WriteLine("Hello, WPF");
        app.Run();
    }
}


// 핵심 2. WPF 기본 어셈블리
//	PresentationCore
//	PresentationFramework
//	System
//	System.Xaml
//	WindowsBase