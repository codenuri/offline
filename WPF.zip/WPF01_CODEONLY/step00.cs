﻿// 1. 빈프로젝트(.Net Framework)
// 2. C# 코드파일 추가
using System;

public class Program
{
    public static void Main()
    {
        Console.WriteLine("Hello, WPF");
    }
}