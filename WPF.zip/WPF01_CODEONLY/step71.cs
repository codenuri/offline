﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

public class MainWindow : System.Windows.Window
{
    protected void InitializeComponent()
    {
    }

    public MainWindow()
    {
        InitializeComponent();
    }

    
    public void button1_click(object sender, RoutedEventArgs e)
    {
        Button btn = sender as Button;
        string s1 = btn.Content as string;
        Console.WriteLine($"Click , {s1}");
    }
}

public class App : System.Windows.Application
{
    [STAThread]
    public static void Main()
    {
        App app = new App();

        MainWindow win = null;

        using (FileStream fs = new FileStream("../../step71.xaml", FileMode.Open))
        {
            win = (MainWindow)XamlReader.Load(fs);
        }
//        Grid grid = (Grid)win.Content;
//        Button btn = (Button)grid.FindName("button1");
//        btn.Click += win.button1_click;



        app.Run(win);
    }
}

