﻿// Step20. Making Window
// 1. PresentationCore 필요
// 2. 프로젝트 속성에서 Windows Application 으로 변경

using System;
using System.Windows;

public class Program
{
    [STAThread]
    public static void Main()
    {  
        Application app = new Application();
        
        Window win = new Window();

        // 방법 1. 
//      app.Run(win);      

        // 방법 2. app.MainWindow 속성에 추가
        win.Show();                 // PresentationCore 필요
        app.MainWindow = win;        
        app.Run();
    }     
}
