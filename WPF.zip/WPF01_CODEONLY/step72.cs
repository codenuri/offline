﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

public class MainWindow : System.Windows.Window
{
    protected void InitializeComponent()
    {
    }

    public MainWindow()
    {
        InitializeComponent();
    }


    public void button1_click(object sender, RoutedEventArgs e)
    {
        Button btn = sender as Button;
        string s1 = btn.Content as string;
        Console.WriteLine($"Click , {s1}");
    }
}

public class App : System.Windows.Application
{
    [STAThread]
    public static void Main()
    {
        App app = null;

        using (FileStream fs = new FileStream("../../step72_App.xaml", FileMode.Open))
        {
            app = (App)XamlReader.Load(fs);
        }


        MainWindow win = null;

        using (FileStream fs = new FileStream("../../step72_MainWindow.xaml", FileMode.Open))
        {
            win = (MainWindow)XamlReader.Load(fs);
        }

        app.Run(win);
    }
}

