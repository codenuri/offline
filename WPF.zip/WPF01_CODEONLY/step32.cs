﻿// Step32. Application 객체의 Event 처리 방법 정리
// 핵심 1. delegate 에 함수 등록
//     2. override function 사용

using System;
using System.Windows;

public class App : System.Windows.Application
{
    public void AppStartup(object sender, StartupEventArgs e)
    {
        Console.WriteLine("delegate AppStartup");
    }
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        Console.WriteLine("override OnStartup");
    }
    [STAThread]
    public static void Main()
    {
        App app = new App();

        app.Startup += app.AppStartup;
        
        app.Run(new Window());
    }
}

