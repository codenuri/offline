﻿// Step31. Application 객체의 Event 처리 방법 2
// 핵심 1. System.Windows.Application 파생 클래스를 만들고
//     2. OnStartUp 가상 메소드 재정의
//     3. Main 함수도 이동

using System;
using System.Windows;

public class App : System.Windows.Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        Console.WriteLine("OnStartup");
    }

    [STAThread]
    public static void Main()
    {
        App app = new App();
        app.Run(new Window());
    }
}

/*
public class Program
{
    [STAThread]
    public static void Main()
    {
        App app = new App();
        app.Run(new Window());
    }
}
*/