﻿// Step10. Application 클래스
// 참조(reference) 추가
//1. PresentationFramwork
//2. WindowsBase

using System;
using System.Windows;

public class Program
{
    public static void Main()
    {
        Application app = new Application();
        Console.WriteLine("Hello, WPF");
        app.Run();     
    }
}
