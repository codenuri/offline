﻿// Step40.
// 핵심 1. Window 객체의 이벤트 처리 방법1 
//  => delegate 사용

// 핵심 2. WPF 기본 어셈블리
//	PresentationCore
//	PresentationFramework
//	System
//	System.Xaml
//	WindowsBase

// 핵심 3. Main Window 참조 얻는 방법
// => app.MainWindow

using System;
using System.Windows;
using System.Windows.Input;

public class App : System.Windows.Application
{
    public void WindowMouseDown(object sender, MouseButtonEventArgs e)
    {
        //      Window win = (Window)sender;
        Window win = this.MainWindow;

        Console.WriteLine("MouseDown");

        Point p = e.GetPosition(win);

        switch (e.ChangedButton)
        {
            case MouseButton.Left:
                Console.WriteLine($"Left {p.X} {p.Y}");
                break;

            case MouseButton.Right:
                Console.WriteLine($"Right {p.X} {p.Y}");
                break;
        }
    }

    [STAThread]
    public static void Main()
    {
        App app = new App();

        Window win = new Window();

        win.MouseDown += app.WindowMouseDown;

        app.Run(win);
    }
}

