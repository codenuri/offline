﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BIND1
{
    public class People : DependencyObject
    {
        private static readonly DependencyProperty MyNameProperty = DependencyProperty.Register("NameChanged", typeof(string), typeof(People),
        new FrameworkPropertyMetadata(new PropertyChangedCallback(Foo)));

        private static void Foo(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            string oldValue = (string)e.OldValue;
            string newValue = (string)e.NewValue;

          
            Console.WriteLine($"Foo : {d.GetHashCode()} {d.GetType().FullName} {oldValue} => {newValue}");
        }

        private string myname;
        public string MyName
        {
            get { return myname; }
            set { myname = value; SetValue(MyNameProperty, myname); }
        }
    }

    public partial class Step2 : Window
    {
        public People p1 = new People();
        public People p2 = new People();

        public Step2()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Random r = new Random();
                       
            p1.MyName = "Kim" + r.Next(16).ToString();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Random r = new Random();

            p2.MyName = "Kim" + r.Next(16).ToString();
        }
    }
}
