﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace MS_SAMPLE_TEST
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
