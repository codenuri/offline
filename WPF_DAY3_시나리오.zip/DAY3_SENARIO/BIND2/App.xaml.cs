﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace BIND2
{
    public class People : INotifyPropertyChanged
    {
        //public string Name { get; set; } = "UNKNOWN";
        public string Address { get; set; } = "SEOUL";

        private string name;
        public string Name
        {
            get { return name; }
            set { name = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Name"));


            }
        }   

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, e);
        }
    }

    /// <summary>
    /// App.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class App : Application
    {
    }
}
