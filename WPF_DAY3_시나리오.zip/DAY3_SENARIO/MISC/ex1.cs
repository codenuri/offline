﻿using System;

class Program
{
    public static void Main()
    {
        var p = new Program();

        var t = p.GetType();

        Console.WriteLine(t.BaseType);
    }
}
