﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ANIMATION
{
    public partial class CodeAnimation : Window
    {

        private Storyboard storyBoard = new Storyboard();

        public CodeAnimation()
        {
            InitializeComponent();

            DoubleAnimation anim1 = new DoubleAnimation();

            anim1.From = 50;
            anim1.To = 250;
            anim1.Duration = TimeSpan.FromSeconds(1);
            anim1.AutoReverse = true;

            Storyboard.SetTarget(anim1, redBall);
            Storyboard.SetTargetProperty(anim1, new PropertyPath("(Ellipse.Width)"));

            DoubleAnimation anim2 = new DoubleAnimation();

            anim2.From = 10;
            anim2.To = 200;
            anim2.Duration = TimeSpan.FromSeconds(1);
            anim2.AutoReverse = true;
            anim2.BeginTime = TimeSpan.FromSeconds(2);

            Storyboard.SetTarget(anim2, redBall);
            Storyboard.SetTargetProperty(anim2, new PropertyPath("(Canvas.Left)"));

            storyBoard.Children.Add(anim1);
            storyBoard.Children.Add(anim2);
        }


        
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            DoubleAnimation anim = new DoubleAnimation();

            anim.From = 50;
            anim.To = 250;
            anim.Duration = TimeSpan.FromSeconds(1);
            anim.AutoReverse = true;
            anim.RepeatBehavior = RepeatBehavior.Forever;

            redBall.BeginAnimation(Ellipse.WidthProperty, anim);

        }
        private void button2_Click(object sender, RoutedEventArgs e)
        {
            DoubleAnimation anim = new DoubleAnimation();

            anim.From = 10;
            anim.To = 200;
            anim.Duration = TimeSpan.FromSeconds(1);
            anim.AutoReverse = true;
            anim.RepeatBehavior = RepeatBehavior.Forever;

            redBall.BeginAnimation(Canvas.LeftProperty, anim);
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            Storyboard sb = new Storyboard();

            DoubleAnimation anim1 = new DoubleAnimation();

            anim1.From = 50;
            anim1.To = 250;
            anim1.Duration = TimeSpan.FromSeconds(1);
            anim1.AutoReverse = true;
            anim1.RepeatBehavior = RepeatBehavior.Forever;

            Storyboard.SetTarget(anim1, redBall);
            Storyboard.SetTargetProperty(anim1, new PropertyPath("(Ellipse.Width)"));


            DoubleAnimation anim2 = new DoubleAnimation();

            anim2.From = 10;
            anim2.To = 200;
            anim2.Duration = TimeSpan.FromSeconds(1);
            anim2.AutoReverse = true;
            anim2.RepeatBehavior = RepeatBehavior.Forever;

            Storyboard.SetTarget(anim2, redBall);
            Storyboard.SetTargetProperty(anim2, new PropertyPath("(Canvas.Left)"));

            sb.Children.Add(anim1);
            sb.Children.Add(anim2);

            sb.Begin();

        }

















        private void button4_Click(object sender, RoutedEventArgs e)
        {
            storyBoard.Begin();
        }

        private void button5_Click(object sender, RoutedEventArgs e)
        {
            storyBoard.Stop();
        }
    }

}