﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace EXAMPLE
{
    /// <summary>
    /// CARD_GAME.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class CARD_GAME : Window
    {

        Button first;
        Button second;
        string[] strImageName = { "AH", "2H", "3H", "4H", "5H", "6H", "7H", "8H" };
        DispatcherTimer myTimer = new DispatcherTimer();
        int matched = 0;

        Image[] imgCard = new Image[8];
        Image imgBack = null;

        public CARD_GAME()
        {
            InitializeComponent();

            boardSet();

            LoadImage();

            // 타이머 객체 생성
            myTimer.Interval = new TimeSpan(0, 0, 0, 0, 750); // 0.75초
            myTimer.Tick += MyTimer_Tick;
        }

        private void LoadImage()
        {
            imgBack = MakeImage("/Image/blue_back.jpg");

            for (int i = 0; i < 8; i++)
            {
                imgCard[i] = MakeImage("/Image/" + strImageName[i] + ".jpg");
            }
        }


        private void MyTimer_Tick(object sender, EventArgs e)
        {
            myTimer.Stop();

            first.Content = imgBack;
            second.Content = imgBack;
            first = null;
            second = null;
        }

        // 
        private void boardSet()
        {
            for (int i = 0; i < 16; i++)
            {
                Button c = new Button();
                c.Background = Brushes.White;
                c.Margin = new Thickness(10);
                c.Content = MakeImage("/Image/blue_back.jpg");
                c.Tag = TagSet();   // 이 문장이 중요, 그림의 인덱스
                c.Click += Card_Click;
                board.Children.Add(c);
            }
        }

        private Image MakeImage(string v)
        {
            BitmapImage bi = new BitmapImage();
            bi.BeginInit();
            bi.UriSource = new Uri(v, UriKind.Relative);
            bi.EndInit();

            Image myImage = new Image();
            myImage.Margin = new Thickness(10);
            myImage.Stretch = Stretch.Fill;
            myImage.Source = bi;

            return myImage;
        }
        //--------------------------------


        // 0~7사이의 정수를 만들어 리턴하는 함수
        // 0~15사이의 랜덤값이 중복되지 않게 만들어지고 
        // 이를 8로 나눈 나머지 값을 리턴합니다.

        int[] rnd = new int[16];  // 랜덤 숫자가 중복되는지 체크

        private int TagSet()
        {
            int i;

            Random r = new Random();

            while (true)
            {
                i = r.Next(16); // 0~15까지

                if (rnd[i] == 0)
                {
                    rnd[i] = 1;
                    break;
                }
            }
            return i % 8; // 태그는 0~7까지, 8개의 그림을 표시
        }

        //------------------------------------------------

        private void Card_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;

            // 버튼에 따른 그림 Load
            string imgNo = strImageName[(int)btn.Tag];

            if (first == null) // 이 버튼은 첫번째 버튼
            {
                first = btn;
                btn.Content = MakeImage("/Image/" + imgNo + ".jpg");
                return;
            }
            else if (second == null)
            {
                second = btn;
                btn.Content = MakeImage("/Image/" + imgNo + ".jpg");
            }
            else   // 이미 두개의 버튼이 열렸는데 3번째 버튼을 눌렀을 경우, 아무 일 안하고 리턴
                return;

            // 매치가 되었을 때 (2)
            if ((int)first.Tag == (int)second.Tag)  // (3) 같다면
            {
                first = null;
                second = null;
                matched += 2;
                if (matched >= 16)
                {
                    MessageBoxResult res = MessageBox.Show(
                         "성공! 다시 하시겠습니까?", "Success", MessageBoxButton.YesNo);
                    if (res == MessageBoxResult.Yes)
                    {
                        resetRnd();
                        boardReset();
                        boardSet();
                        matched = 0;
                    }
                }
            }
            // 매치가 안되었을 때는 다시 덮어주어야 한다 (4)
            else
            {
                myTimer.Start();
            }
        }
        // 게임 초기화
        private void boardReset()
        {
            board.Children.Clear();
        }

        // rnd[] 배열 초기화
        private void resetRnd()
        {
            for (int i = 0; i < 16; i++)
                rnd[i] = 0;
        }
    }
}
