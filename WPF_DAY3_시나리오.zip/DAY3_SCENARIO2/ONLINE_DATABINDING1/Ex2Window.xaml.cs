﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DATABINDING1
{
    public partial class Ex2Window : Window
    {
        // 처음에 이것으로
        //public List<Person> st = new List<Person>();

        // 나중에 이것으로
        public ObservableCollection<Person> st = new ObservableCollection<Person>();

        public Ex2Window()
        {
            InitializeComponent();

            st.Add(new Person { Name = "kim1", Address = "jeju1" });
            st.Add(new Person { Name = "kim2", Address = "jeju2" });

            listbox.ItemsSource = st;
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            st[0].Name = "lee";
        }
        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            st.Add(new Person { Name = "kim3", Address = "jeju3" });
        }
    }
}
