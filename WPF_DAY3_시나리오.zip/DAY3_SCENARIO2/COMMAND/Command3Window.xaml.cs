﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace COMMAND
{
    public class ActionCommand2 : ICommand
    {
        public event EventHandler CanExecuteChanged;

        public TextBox txtBox = null;

        public void FireCanExecute()
        {
            // CanExecute 를 다시 호출해 달라는 의미.
            CanExecuteChanged(this, EventArgs.Empty);
        }

        public bool CanExecute(object parameter)
        {
            Console.WriteLine("CanExecute");

            if (txtBox == null)
                txtBox = ((Command3Window)Application.Current.MainWindow).txtBox;

            return !string.IsNullOrEmpty(txtBox.Text);
        }

        public void Execute(object parameter)
        {
            MessageBox.Show(txtBox?.Text);
        }
    }

    static class MyCommand2
    {
        public static ActionCommand2 cmdAction = new ActionCommand2();
    }



    public partial class Command3Window : Window
    {
        public Command3Window()
        {
            InitializeComponent();
        }

        private void txtBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            MyCommand2.cmdAction.FireCanExecute();
        }
    }
}
