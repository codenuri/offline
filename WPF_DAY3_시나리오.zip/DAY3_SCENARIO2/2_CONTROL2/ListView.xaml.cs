﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _2_CONTROL2
{
    /// <summary>
    /// ListView.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ListView : Window
    {
        public ListView()
        {
            InitializeComponent();
              
            
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            CONTROL.VisualTree vt = new CONTROL.VisualTree();

            vt.Process(this);
            vt.Show();
        }
    }
}

// https://www.c-sharpcorner.com/UploadFile/mahesh/listview-in-wpf/ 참고

