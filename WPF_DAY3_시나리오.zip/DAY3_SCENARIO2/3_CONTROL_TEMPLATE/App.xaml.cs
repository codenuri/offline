﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace _3_CONTROL_TEMPLATE
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
