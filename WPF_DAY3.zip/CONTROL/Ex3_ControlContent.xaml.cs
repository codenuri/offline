﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CONTROL
{
    /// <summary>
    /// Ex3_ControlContent.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Ex3_ControlContent : Window
    {
        private Button btn1 = null;   // Content 만 가짐
        private GroupBox gbox = null;   // Header + Content

        public Ex3_ControlContent()
        {
            InitializeComponent();

            /*
            btn1 = new Button();
            btn1.Content = "OK";

            gbox = new GroupBox();
            gbox.Header = "Header";
            gbox.Content = "AAA";

            this.Content = gbox;
            */
        }
    }
}
