﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CONTROL
{
    public class Car
    {
        public Car()
        {
            Console.WriteLine("Car()");
        }
    }
    /// <summary>
    /// Ex2_ControlEvent.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Ex2_ControlEvent : Window
    {
        public Ex2_ControlEvent()
        {
            InitializeComponent();

            button4.AddHandler(Button.ClickEvent, new RoutedEventHandler(Button4_Click), true);
        }
        private void Button4_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Click4");
        }
        private void Button1_Click(object sender, RoutedEventArgs e)
        {

        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;

            string title = (string)btn.Content;

            MessageBox.Show(title);
        }

        private void StackPanel_Click(object sender, RoutedEventArgs e)
        {

            MessageBox.Show("StackPanel_Click");

            Button btn = e.OriginalSource as Button;
            string title = (string)btn.Content;
            MessageBox.Show(title);
        }
    }
}
