﻿// constructor
// OOP2 복사