﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BIND1
{

    public partial class Step1 : Window
    {
        private static readonly DependencyProperty MyNameProperty = DependencyProperty.Register("NameChanged", typeof(string), typeof(Step1), 
            new FrameworkPropertyMetadata(new PropertyChangedCallback(Foo)));

        private string myname;
        public string MyName
        {
            get { return myname; }
            set { myname = value; SetValue(MyNameProperty, myname); }
        }
        private static void Foo(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            string oldValue = (string)e.OldValue;
            string newValue = (string)e.NewValue;

            Console.WriteLine($"Foo : {oldValue} => {newValue}");
        }

        public Step1()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Random r = new Random();

            //SetValue(MyNameProperty, "Kim" + r.Next(16).ToString() );
            MyName = "Kim" + r.Next(16).ToString();
        }
    }
}
