﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BIND1
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Slider1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            label1.FontSize = slider1.Value;
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            Binding binding = new Binding();
            binding.Source = slider2;
            binding.Path = new PropertyPath("Value");
            binding.Mode = BindingMode.TwoWay;
            label1.SetBinding(TextBlock.FontSizeProperty, binding);
            
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            BindingOperations.ClearAllBindings(label1);
        }

        private void Button3_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
