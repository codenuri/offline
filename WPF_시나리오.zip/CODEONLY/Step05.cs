﻿// Step05.cs
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

// 마우스, 키보드 메세지 처리하기


namespace CODEONLY
{
    public class App : System.Windows.Application
    {
        public void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Point p = e.GetPosition(this.MainWindow);

            switch (e.ChangedButton)
            {
                case MouseButton.Left:
                    Console.WriteLine($"Left {p.X} {p.Y}");
                    break;
                case MouseButton.Right:
                    Console.WriteLine($"Right {p.X} {p.Y}");
                    break;
            }
        }

        [STAThread]
        public static void Main()
        {
            App app = new App();

            Window win = new Window();

            win.MouseDown += app.Window_MouseDown;
            //win.KeyDown += app.Window_KeyDown;

            win.Show();  // PresentationCore 필요

            // Main Window 를 등록하는 방법
            // 1. app.MainWindow 에 등록
            // app.MainWindow = win;
            // app.Run();

            // 2. Run 메소드에 인자로 전달
            app.Run(win);
        }
    }
}
