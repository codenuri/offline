﻿// Step09.cs
using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace CODEONLY
{
    public class MainWindow : System.Windows.Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        protected void InitializeComponent()
        {
            DependencyObject rootElement;

            using (FileStream fs = new FileStream("Step9.xaml", FileMode.Open))
            {
                rootElement = (DependencyObject)XamlReader.Load(fs);
            }
            // Windows 에 grid 연결
            this.Content = rootElement;

            // Find the control with the appropriate name.
            //Button btn1 = (Button)LogicalTreeHelper.FindLogicalNode(rootElement, "button1");

            // 위 또는 아래 코드.
            FrameworkElement frameworkElement = (FrameworkElement)rootElement;
            Button btn1 = (Button)frameworkElement.FindName("button1");

            // Wire up the event handler.
            btn1.Click += OnButton1_Click;
        }

        private void OnButton1_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            string s1 = btn.Content as string;
            Console.WriteLine($"Click , {s1}");
        }
    }
    public class App : System.Windows.Application
    {
        [STAThread]
        public static void Main()
        {
            App app = new App();
            MainWindow win = new MainWindow();
            win.Show();
            app.Run(win);
        }
    }
}

/*
// Step09.xaml
<Grid xmlns = "http://schemas.microsoft.com/winfx/2006/xaml/presentation" >
<Button Name="button1"> 확인1</Button>
</Grid>
*/
//------------------