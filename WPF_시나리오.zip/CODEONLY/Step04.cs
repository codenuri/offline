﻿using System;
using System.Windows;

// 핵심 
// 1. Application 파생 클래스 만들기
// 2. Main 을 별도 클래스에 넣는 모델, App 클래스 안에 넣는 모델
// 3. OnXXX() 가상 메소드 정리 할것

// Delegate를 사용한 이벤트 처리 방식 - 인자가 2개
// 가상 함수를 사용한 방식 - 인자가 1개

namespace CODENONLY
{
    public class App : System.Windows.Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            Console.WriteLine("OnStartup");
        }

        [STAThread]
        public static void Main()
        {
            App app = new App();

            app.Run(new Window());
        }
    }
}


/*
public class App : System.Windows.Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        Console.WriteLine("OnStartup");
    }
}
public class CODENONLY
{
    public static void AppStartup(object sender, StartupEventArgs e) { Console.WriteLine("AppStartup"); }
    public static void AppExit(object sender, ExitEventArgs e) { Console.WriteLine("AppExit"); }

    [STAThread]
    public static void Main()
    {
        App app = new App();

        app.Startup += AppStartup;
        app.Exit += AppExit;

        app.Run(new Window());
    }
}
*/
