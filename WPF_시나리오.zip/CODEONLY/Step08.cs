﻿// Step08.cs
using System;
using System.Windows;
using System.Windows.Controls;

// 버튼 이벤트 처리

namespace CODEONLY
{
    public class MainWindow : System.Windows.Window
    {
        private Button btn1 = null;
        private Button btn2 = null;
        private Grid grid = null;

        public MainWindow()
        {
            InitializeComponent();
        }

        protected void InitializeComponent()
        {
            grid = new Grid();

            grid.RowDefinitions.Add(new RowDefinition());
            grid.RowDefinitions.Add(new RowDefinition());

            this.Content = grid;

            btn1 = new Button();
            btn1.Content = "확인1";
            Grid.SetRow(btn1, 0);

            btn2 = new Button();
            btn2.Content = "확인2";
            Grid.SetRow(btn2, 1);

            grid.Children.Add(btn1);
            grid.Children.Add(btn2);

            // button event 처리
            btn1.Click += OnButton1_Click;
        }

        public void OnButton1_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;

            string s1 = btn.Content as string;

            Console.WriteLine($"Click , {s1}");
        }

    }

    public class App : System.Windows.Application
    {
        [STAThread]
        public static void Main()
        {
            App app = new App();

            MainWindow win = new MainWindow();

            win.Show();

            app.Run(win);
        }
    }
}
