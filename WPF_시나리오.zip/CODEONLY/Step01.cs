﻿// Step01.cs
using System;

namespace CODEONLY
{
    public class Entry
    {
        public static void Main()
        {
            Console.WriteLine("Hello, WPF");
        }
    }
}
