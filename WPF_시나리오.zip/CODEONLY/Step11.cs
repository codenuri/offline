﻿// Step11.cs
using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace CODEONLY
{
    public class People
    {
        public string Name { set; get; } = "UNKNOWN";

        public People(string name) { Name = name; Console.WriteLine("People()"); }

        public override string ToString()
        {
            return Name;
        }
    }

    public class MainWindow : System.Windows.Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        protected void InitializeComponent()
        {
        }
        public void OnButton1_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            string s1 = btn.Content as string;
            Console.WriteLine($"Click , {s1}");
        }
    }

    public class App : System.Windows.Application
    {
        [STAThread]
        public static void Main()
        {
            App app = new App();
            Window win = null;
        
            using (FileStream fs = new FileStream("Step11.xaml", FileMode.Open))
            {
                win = (Window)XamlReader.Load(fs);
            }
            win.Show();
            app.Run(win);
        }
    }
}