﻿// Step02.cs
using System;
using System.Windows;

namespace CODEONLY
{
    public class Entry
    {
        [STAThread]
        public static void Main()
        {
            Application app = new Application();

            Console.WriteLine("Hello, WPF");

            app.Run(new Window());
        }
    }
}
