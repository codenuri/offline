﻿// Step10.cs
using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace CODEONLY
{
    public class MainWindow : System.Windows.Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        protected void InitializeComponent()
        {
        }
        private void OnButton1_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            string s1 = btn.Content as string;
            Console.WriteLine($"Click , {s1}");
        }
    }

    public class App : System.Windows.Application
    {
        [STAThread]
        public static void Main()
        {
            App app = new App();
            MainWindow win = null;            
            using (FileStream fs = new FileStream("Step10.xaml", FileMode.Open))
            {
                win = (MainWindow)XamlReader.Load(fs);
            }
            win.Show();
            app.Run(win);
        }
    }
}

/*
// Step10.xaml
<local:MainWindow xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        	  xmlns:local="clr-namespace:CODEONLY;assembly=CODEONLY"
        	  Title="Step10" Height="450" Width="800">

<Grid>
<Button Name = "button1" Click="OnButton1_Click"> 확인1 </Button>
</Grid>
</local:MainWindow>
*/
  