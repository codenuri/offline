﻿// Step03.cs
using System;
using System.Windows;

namespace CODEONLY
{
    public class Entry
    {
        public static void AppStartup(object sender, StartupEventArgs e)
        {
            Console.WriteLine("AppStartup");
        }
        public static void AppExit(object sender, ExitEventArgs e)
        {
            Console.WriteLine("AppExit");
        }
        public static void WindowActivate(object sender, EventArgs e)
        {
            Console.WriteLine("WindowActivate");
        }

        [STAThread]
        public static void Main()
        {
            Application app = new Application();

            app.Startup += AppStartup;
            app.Exit += AppExit;
            app.Activated += WindowActivate;

            app.Run(new Window());
        }
    }
}

