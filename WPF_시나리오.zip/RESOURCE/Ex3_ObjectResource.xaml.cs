﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RESOURCE
{
    /// <summary>
    /// Ex3_ObjectResource.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Ex3_ObjectResource : Window
    {
        public Ex3_ObjectResource()
        {
            InitializeComponent();
        }
        private void change_brush(object sender, RoutedEventArgs e)
        {
            //ImageBrush brush = (ImageBrush)this.Resources["TileBrush"];
            //brush.Viewport = new Rect(0, 0, 5, 5);  

            this.Resources["TileBrush"] = new SolidColorBrush(Colors.LightBlue);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.Resources["RedBrush"] = new SolidColorBrush(Colors.Red);
        }
    }
}
