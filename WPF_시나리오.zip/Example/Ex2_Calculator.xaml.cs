﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Example
{
    /// <summary>
    /// Ex2_Calculator.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Ex2_Calculator : Window
    {
        public Ex2_Calculator()
        {
            InitializeComponent();
        }

        private double savedValue = 0;
        private char op;
        private bool newButton = false;


        private void num_click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;

            string number = btn.Content.ToString();

            if (txtResult.Text == "0" || newButton == true)
            {
                txtResult.Text = number;
                newButton = false;
            }
            else
                txtResult.Text = txtResult.Text + number;
        }

        private void dot_click(object sender, RoutedEventArgs e)
        {
            if (txtResult.Text.Contains(".") == false)
                txtResult.Text += ".";
        }



        private void op_click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;

            savedValue = double.Parse(txtResult.Text);// string의 첫번째 요소 값
            op = btn.Content.ToString()[0];
            newButton = true;
        }

        private void equal_click(object sender, RoutedEventArgs e)
        {
            if (op == '+')
                txtResult.Text = (savedValue + double.Parse(txtResult.Text)).ToString();
            else if (op == '-')
                txtResult.Text = (savedValue - double.Parse(txtResult.Text)).ToString();
            else if (op == '*')
                txtResult.Text = (savedValue * double.Parse(txtResult.Text)).ToString();
            else if (op == '/')
                txtResult.Text = (savedValue / double.Parse(txtResult.Text)).ToString();
        }
    }
}
