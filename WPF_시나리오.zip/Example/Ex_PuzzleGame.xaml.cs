﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Example
{
    public partial class Ex_PuzzleGame : Window
    {
        BitmapImage bmpImage = new BitmapImage();
        private double imgWidth = 0;
        private double imgHeight = 0;
        private Image[,] image_arr = new Image[5, 5];

        public Ex_PuzzleGame()
        {
            InitializeComponent();
            InitBoard();
        }

        // 그림 부분 출력
        /*
        public void InitBoard()
        {
            BitmapImage bmpImage = new BitmapImage();
            bmpImage.BeginInit();
            bmpImage.UriSource = new Uri("/image/totoro.jpg", UriKind.Relative);
            bmpImage.EndInit();

            Image image = new Image();
            image.Source = bmpImage;
            RectangleGeometry area = new RectangleGeometry(new Rect(0, 0, 100, 100));
            image.Clip = area;

            BoardGrid.Children.Add(image);
        }
        */
        public void InitBoard()
        {
            // Grid 5 * 5 생성
            for (int i = 0; i < 5; i++)
            {
                RowDefinition row = new RowDefinition();
                BoardGrid.RowDefinitions.Add(row);
            }
            for (int i = 0; i < 5; i++)
            {
                ColumnDefinition col = new ColumnDefinition();
                BoardGrid.ColumnDefinitions.Add(col);
            }
            // Bitmap Image 생성
            BitmapImage bmpImage = new BitmapImage();
            bmpImage.BeginInit();
            bmpImage.UriSource = new Uri("/image/totoro.jpg", UriKind.Relative);            
            bmpImage.EndInit();

            // image arr 생성
            for ( int y = 0; y < 5; y++)
                for ( int x = 0; x < 5; x++)
                {
                    Image img = new Image();
                    img.Source = bmpImage;
                    img.Stretch = Stretch.None;
                    RectangleGeometry area = new RectangleGeometry(new Rect(0, 0, 100, 100));
                    img.Clip = area;
                    BoardGrid.Children.Add(img);
                    Grid.SetRow(img, y);
                    Grid.SetColumn(img, x);                    
                }
        }

    }
}
