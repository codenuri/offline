﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RAUTEDEVENT
{
    /// <summary>
    /// Ex2_KeyPressEvent.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Ex2_KeyPressEvent : Window
    {
        public Ex2_KeyPressEvent()
        {
            InitializeComponent();
        }
        private void KeyEvent(object sender, KeyEventArgs e)
        {        
            string message = "(KeyEvent)Event: " + e.RoutedEvent + " " + " Key: " + e.Key;

            Console.WriteLine(message);
        }

        private void textInput(object sender, TextCompositionEventArgs e)
        {
            string message = "(textInput)Event: " + e.RoutedEvent + " " + " Text: " + e.Text;
            Console.WriteLine(message);
        }

        private void TextChanged(object sender, TextChangedEventArgs e)
        {
            string message = "(TextChanged)Event: " + e.RoutedEvent;
            Console.WriteLine(message);
        }
    }
}

private void KeyEvent(object sender, KeyEventArgs e)
{
    string message = "(KeyEvent)Event: " + e.RoutedEvent + " " + " Key: " + e.Key;

    Console.WriteLine(message);
}

private void textInput(object sender, TextCompositionEventArgs e)
{
    string message = "(textInput)Event: " + e.RoutedEvent + " " + " Text: " + e.Text;
    Console.WriteLine(message);
}

private void TextChanged(object sender, TextChangedEventArgs e)
{
    string message = "(TextChanged)Event: " + e.RoutedEvent;
    Console.WriteLine(message);
}