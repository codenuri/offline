﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RAUTEDEVENT
{
    /// <summary>
    /// Ex4_AddHandler.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Ex4_AddHandler : Window
    {
        public Ex4_AddHandler()
        {
            InitializeComponent();
        }
        private void Button_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Console.WriteLine("MouseDown");
        }

        private void Button_MouseUp(object sender, MouseButtonEventArgs e)
        {
            Console.WriteLine("MouseUp");
        }

        private void Label_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Console.WriteLine("label MouseDown");
        }

        private void Label_MouseUp(object sender, MouseButtonEventArgs e)
        {
            Console.WriteLine("label MouseUp");
        }
        private void Backdoor(object sender, RoutedEventArgs e)
        {
            Console.WriteLine("button mouseup");
        }
    }
}
