﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RAUTEDEVENT
{
    /// <summary>
    /// Ex1_RautedEvent.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Ex1_RautedEvent : Window
    {
        public Ex1_RautedEvent()
        {
            InitializeComponent();
        }

        private void Label_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Console.WriteLine("Label_MouseDown");
        }
        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Console.WriteLine("Grid_MouseDown");
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Console.WriteLine("Window_MouseDown");
        }

        private void Window_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Console.WriteLine("Window_PreviewMouseDown");
        }

        private void Grid_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Console.WriteLine("Grid_PreviewMouseDown");
        }

        private void Label_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Console.WriteLine("Label_PreviewMouseDown");
        }


    }
}

