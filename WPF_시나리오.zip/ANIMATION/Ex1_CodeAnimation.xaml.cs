﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace ANIMATION
{
    /// <summary>
    /// Ex1_CodeAnimation.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Ex1_CodeAnimation : Window
    {
        public Ex1_CodeAnimation()
        {
            InitializeComponent();
        }

        private void Animation_Completed(object sender, EventArgs e)
        {
            Console.WriteLine("Animation Completed");
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            // Width 속성 변경
            DoubleAnimation anim1 = new DoubleAnimation();
            anim1.From = RedBall.Width;
            anim1.To   = RedBall.Width + 100;
            anim1.Duration = new TimeSpan(0, 0, 3);

            //   anim1.Completed += Animation_Completed;                  

            RedBall.BeginAnimation(Ellipse.WidthProperty, anim1);
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            DoubleAnimation anim1 = new DoubleAnimation();
            anim1.Duration = TimeSpan.FromSeconds(3);
            RedBall.BeginAnimation(Ellipse.WidthProperty, anim1);
        }

        private void Button3_Click(object sender, RoutedEventArgs e)
        {
            DoubleAnimation anim1 = new DoubleAnimation();
            anim1.From = (double)RedBall.GetValue(Canvas.LeftProperty);
            anim1.To = (double)RedBall.GetValue(Canvas.LeftProperty) + 100;
            anim1.Duration = TimeSpan.FromSeconds(3);

            RedBall.BeginAnimation(Canvas.LeftProperty, anim1);
        }
        private void Button4_Click(object sender, RoutedEventArgs e)
        {
            DoubleAnimation anim1 = new DoubleAnimation();
            anim1.By = -30;
            anim1.Duration = TimeSpan.FromSeconds(1);

            RedBall.BeginAnimation(Canvas.LeftProperty, anim1);
        }

        // DispatcherTimer 사용
        private DispatcherTimer MyTimer = new DispatcherTimer();
        
        private void Button5_Click(object sender, RoutedEventArgs e)
        {
            MyTimer.Interval = new TimeSpan(30); // 30 nano
            MyTimer.Tick += UpdateRedBall;
            MyTimer.Start();
        }

        private double xPos = 0;

        void UpdateRedBall(object sender, EventArgs e)
        {
            Canvas.SetLeft(RedBall, xPos);
            if (xPos > this.Width)
                xPos = 0;
            else
                xPos += 0.1;
            Thread.Sleep(1);
        }
        private void Button6_Click(object sender, RoutedEventArgs e)
        {
            MyTimer.Stop();
        }

        private void Button7_Click(object sender, RoutedEventArgs e)
        {
            CompositionTarget.Rendering += new EventHandler(CompositionTarget_Rendering);
        }

        private void Button8_Click(object sender, RoutedEventArgs e)
        {
            CompositionTarget.Rendering -= new EventHandler(CompositionTarget_Rendering);
        }
        void CompositionTarget_Rendering(object sender, EventArgs e)
        {
            Canvas.SetLeft(RedBall, xPos);
            if (xPos > this.Width)
                xPos = 0;
            else
                xPos += 0.5;

        }

    }
}
