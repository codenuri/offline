﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CONTROL
{
    /// <summary>
    /// Ex5_ControlExample2.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Ex5_ControlExample2 : Window
    {
        public Ex5_ControlExample2()
        {
            InitializeComponent();
            BuildTree();
        }


        private void BuildTree()
        {
            treeFileSystem.Items.Clear();

            foreach (DriveInfo drive in DriveInfo.GetDrives())
            {
                TreeViewItem item = new TreeViewItem();
                item.Tag = drive;
                item.Header = drive.ToString();

                // This placeholder string is never shown,
                // because the node begins in collapsed state.
                item.Items.Add("*");

                treeFileSystem.Items.Add(item);
            }
        }

        private void item_Expanded(object sender, RoutedEventArgs e)
        {
            TreeViewItem item = (TreeViewItem)e.OriginalSource;

            item.Items.Clear();

            DirectoryInfo dir;

            if (item.Tag is DriveInfo)
            {
                DriveInfo drive = (DriveInfo)item.Tag;
                dir = drive.RootDirectory;
            }
            else
            {
                dir = (DirectoryInfo)item.Tag;
            }

            try
            {
                foreach (DirectoryInfo subDir in dir.GetDirectories())
                {
                    TreeViewItem newItem = new TreeViewItem();
                    newItem.Tag = subDir;
                    newItem.Header = subDir.ToString();
                    newItem.Items.Add("*");
                    item.Items.Add(newItem);
                }
            }
            catch
            {

            }
        }

        private void TreeFileSystem_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            TreeViewItem item = (TreeViewItem)treeFileSystem.SelectedItem;

            string s = item.Header.ToString();

            while (item != null)
            {
                ItemsControl parent = GetSelectedTreeViewItemParent(item);

                if (parent is TreeViewItem)
                {

                    item = parent as TreeViewItem;

                    string MyValue = item.Header.ToString();//Gets you the immediate parent

                    s = MyValue + "\\" + s;
                }
                else
                    break;
            }
            //MessageBox.Show(s);

            listview_refresh(s);
        }

        // VisualTreeHelper 를 먼저 설명 할것.!!
        public ItemsControl GetSelectedTreeViewItemParent(TreeViewItem item)
        {
            DependencyObject parent = VisualTreeHelper.GetParent(item);

            while (!(parent is TreeViewItem || parent is TreeView))
            {
                parent = VisualTreeHelper.GetParent(parent);
            }

            return parent as ItemsControl;
        }

        private void listview_refresh(string path)
        {
            DirectoryInfo dir = new DirectoryInfo(path);
                        
            listview.ItemsSource = dir.GetDirectories();

            //GridView gv = new GridView();
            
        }
    }
}
