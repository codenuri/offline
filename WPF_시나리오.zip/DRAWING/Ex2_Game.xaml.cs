﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DRAWING
{
    /// <summary>
    /// Ex2_Game.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Ex2_Game : Window
    {
        private int[,] placement = new int[4, 4];
        private bool isShuffled = false;

        public Ex2_Game()
        {
            InitializeComponent();

            BoardSet();     // Board setting
            InitBoard();    // 초기화면처럼 순서대로 배치
            DrawBoard();    // placement[,] 배열에 따라 버튼 그리기
        }

        // Grid Board를 4x4로 분할한다
        private void BoardSet()
        {
            for (int i = 0; i < 4; i++)
            {
                RowDefinition row = new RowDefinition();
                Board.RowDefinitions.Add(row);
            }
            for (int i = 0; i < 4; i++)
            {
                ColumnDefinition col = new ColumnDefinition();
                Board.ColumnDefinitions.Add(col);
            }
        }
        // 1~15까지의 숫자를 순서대로 배치한다
        private void InitBoard()
        {
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    placement[i, j] = i * 4 + j + 1;
            placement[3, 3] = 0;
        }

        // placement[,] 배열의 내용을 읽어서 Board에 그려준다
        private void DrawBoard()
        {
            for (int row = 0; row < 4; row++)
            {
                for (int col = 0; col < 4; col++)
                {
                    if (placement[row, col] != 0)
                    {
                        Button btn = new Button();
                        btn.Margin = new Thickness(1);
                        btn.FontSize = 15;
                        btn.FontWeight = FontWeights.Bold;
                        btn.Content = placement[row, col].ToString();
                        btn.Name = "btn" + row.ToString() + col.ToString();
                        btn.Click += btn_Click;
                        Board.Children.Add(btn);
                        Grid.SetRow(btn, row);
                        Grid.SetColumn(btn, col);
                    }
                }
            }
        }
        // 겹치지 않는 0~15까지의 랜덤 생성
        private void btnShuffle_Click(object sender, RoutedEventArgs e)
        {
            isShuffled = true;

            Board.Children.Clear();
            RandomPlacement();

            DrawBoard();
        }

        // placement[] 배열에 서로 겹치지 않는 0~15까지의 숫자를 할당한다
        private void RandomPlacement()
        {
            int[] flag = new int[16];   // 0으로 초기화된다
            Random r = new Random();

            for (int row = 0; row < 4; row++)
            {
                for (int col = 0; col < 4; col++)
                {
                    int num = r.Next(16);
                    while (flag[num] != 0)
                        num = r.Next(16);
                    flag[num] = 1;
                    placement[row, col] = num;
                }
            }
        }


        private void btn_Click(object sender, EventArgs e)
        {
            if (isShuffled == false)
            {
                MessageBox.Show("Press Shuffle Button First, before you Start the Game!");
                return;
            }

            Button btn = sender as Button;
        int eRow = -1, eCol = -1;   // Empty 좌표
        int row = Convert.ToInt32(btn.Name.Remove(0, 3)) / 10;
        int col = Convert.ToInt32(btn.Name.Remove(0, 3)) % 10;

      // 이웃한 공간을 검색
      if (row - 1 >= 0 && placement[row - 1, col] == 0)    // North
      { eRow = row - 1; eCol = col; }
      else if (row + 1 <= 3 && placement[row + 1, col] == 0) // South
      { eRow = row + 1; eCol = col; }
      else if (col + 1 <= 3 && placement[row, col + 1] == 0)   // East
      { eRow = row; eCol = col + 1; }
      else if (col - 1 >= 0 && placement[row, col - 1] == 0)    // West
      { eRow = row; eCol = col - 1; }

      // 이웃 공간에 빈칸이 없다. 끝
      if (eRow == -1) return;

      // 이웃 공간에 빈칸이 있다 -> 클릭된 버튼을 빈칸으로 이동
      // 이 버튼의 좌표를 (x, y)에서 (emptyX, emptyY)로 이동
      btn.Name = "btn" + eRow.ToString() + eCol.ToString();
      placement[eRow, eCol] = placement[row, col];
      placement[row, col] = 0;
        Board.Children.Clear();
      DrawBoard();

        checkComplete();
    }

    private void checkComplete()
    {
        if (isShuffled == false)
            return;

        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++)
                if (placement[i, j] != i * 4 + j + 1)
                {
                    if (i == 3 && j == 3)
                        MessageBox.Show("Congraturation!! You Completed!");
                    return;
                }
    }
}
    }
