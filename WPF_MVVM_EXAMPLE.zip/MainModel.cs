﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_MVVM_EXAMPLE
{
    public class MainModel
    {
        public string dollar;
        public string won;
    }
}
