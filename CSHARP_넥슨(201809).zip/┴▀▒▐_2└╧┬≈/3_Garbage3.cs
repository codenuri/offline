﻿using System;
using static System.Console;

// root : 객체가 살아있음을 판단할때 사용하는 변수
//        지역변수, 함수인자, static 멤버 변수
//       
// 일반 멤버 변수는 root 가 아니다.

// GC.Collect() : 모든 root 변수가 참조 하는 모든 객체는 살아있다고 판단
//                  

class People
{
    public string name = null;
    public People bestFriend = null;
    public People(string n) { name = n; }
    ~People() { WriteLine("{0} Destroy", name); }
}

class Program
{

    static void Main(string[] args)
    {
        People p1 = new People("AAA");
        People p2 = new People("BBB");

        p1.bestFriend = p2;
        p2.bestFriend = p1;

        p1 = null;
        p2 = null;

        GC.Collect();
        GC.WaitForPendingFinalizers();

        WriteLine("-------------");

        if (p1 != null) WriteLine(p1.name);
        if (p2 != null) WriteLine(p2.name);
    }
}
