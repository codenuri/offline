﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using static System.Console;

// [OptionalField(VersionAdded = 2)]

[Serializable]
class People
{
    public string name;   
    public int age;

    [NonSerialized] public bool isChild;

    public People bestFriend = null;
    public People(string n, int a)
    {
        name = n;
        age = a;
        isChild = (age < 13);
    }

 
}

class Program
{
    public static void Main()
    {
        IFormatter format = new BinaryFormatter();
        using (FileStream fs = File.OpenRead("Data.bin"))
        {
            People p = (People)format.Deserialize(fs);

            WriteLine("{0} {1}", p.name, p.age);
            WriteLine("{0} {1}", p.bestFriend.name, p.bestFriend.age);
        }
    }

}