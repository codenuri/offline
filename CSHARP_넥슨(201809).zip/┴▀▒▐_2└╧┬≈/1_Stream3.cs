﻿using System;
using static System.Console;

class Fighter
{
    public void Fire() { WriteLine("Fire Missile"); }
}

// 포함 : 클래스가 아닌 객체에 기능 추가
//        컴파일 시간이 아닌 실행시간에 기능 추가.

class LeftMissile
{
    public Fighter fg = null; // 포함
    public LeftMissile( Fighter f ) { fg = f; }
    public void Fire()
    {
        fg.Fire(); // 원래 기능 수행
        WriteLine("Fire Left Missile"); // 새로운 기능 수행.
    }
}

class Program
{
    static void Main()
    {
        Fighter f = new Fighter();
        f.Fire();

        // 아이템 획득
        LeftMissile lm = new LeftMissile(f);
        lm.Fire();
    }
}


