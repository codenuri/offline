﻿using System;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Xml;
using static System.Console;

class Program
{
    /*
    static void Main()
    {
        // 기능 추가의 대상 : backing store( 최종 저장소)
        FileStream fs = new FileStream("a.txt", FileMode.Create);


        // 기능 추가객체
        GZipStream gs = new GZipStream(fs, CompressionLevel.Fastest);

      //  CryptoStream cs = new CryptoStream(gs, ICryptoTransform.ReferenceEquals,
      //                                  CryptoStreamMode.Write);

        byte[] b = { 65, 66, 67, 68, 69, 0 };

        //fs.Write(b, 0, 6);
        gs.Write(b, 0, 6);
        //cs.Write(b, 0, 6);

        gs.Dispose();
        fs.Dispose();
    }
    */
    static void Main()
    {        
        FileStream fs = new FileStream("a.txt", FileMode.Create);

        byte[] b = { 65, 66, 67, 68, 69, 0 };
        fs.Write(b, 0, 6);


        StreamWriter sw = new StreamWriter(fs);
        sw.WriteLine("Hello");

       // XmlWriter xw = new XmlStremWriter(fs);
       // xw.WriteAttributeString("NAME", "Kim");

        fs.Dispose();
    }

}







