﻿using System;
using System.Threading;
using static System.Console;


// Finallizer
class ObjectA
{
    public string name = null;
    public ObjectA(string n) { name = n; }
}
class ObjectB
{
    public string name = null;
    public ObjectB(string n) { name = n; }

    // Finallizer
    // 1. 아래 함수 호출
    // 2. 쓰레기 수집(메모리해지).
    ~ObjectB() { WriteLine("{0} Destroy {1}", name, 
        Thread.CurrentThread.ManagedThreadId); }
}
//  C# : 3세대 Generation 방식의 쓰레기 수집기
// mono 2.8 이전 : Mark And Sweep, 
// mono 2.8 이후 : 2세대 방식의 쓰레드 수집기(SGen)

class Program
{
    static void Main(string[] args)
    {
        WriteLine("{0}", Thread.CurrentThread.ManagedThreadId);

        Object oa = new ObjectA("A");
        Object ob = new ObjectB("B");

        WriteLine(GC.GetGeneration(oa)); // 0
        WriteLine(GC.GetGeneration(ob)); // 0

        oa = null;
        ob = null;

        GC.Collect(0);  // Finallizer 가 없는 모든 객체는 수집됨
                    // A 는 즉시 쓰레기 수집
                    // B 는 소멸자 호출을 대기하는 Q에 참조가 생기고
                    //   실제 메모리는 1세대로 이동
                    //   소멸자 호출을 위한 새로운 쓰레드 생성해서
                    //   소멸자 호출.
        WriteLine(GC.GetTotalMemory(false)); 
        GC.WaitForPendingFinalizers();
        GC.Collect(1); // 이 순간 이제 B의 메모리 해제..


        WriteLine(GC.GetTotalMemory(false));
    }
}

