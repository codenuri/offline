﻿using System;
using System.Net;
using static System.Console;

// 

class Program
{
    static void Main()
    {
        string s = null;

        using (WebClient wc = new WebClient())
        {
            try
            {
                s = wc.DownloadString("http://wwww.naver.com");
                WriteLine(s);
            }
            catch( WebException e) when( e.Status ==
                                    WebExceptionStatus.Timeout)
            {
                //...
            }
            catch (WebException e) 
            {
                //...
            }
        }

        //wc.Dispose();
    }
}





