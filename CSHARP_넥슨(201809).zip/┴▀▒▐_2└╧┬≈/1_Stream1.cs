﻿


// cafe.naver.com/codenuri    게시판에서

// 2일차 사전 소스 받으시면 됩니다.







using System;
using static System.Console;

class Fighter
{
    public void Fire() { WriteLine("Fire Missile"); }
}

class Program
{
    static void Main()
    {
        Fighter f = new Fighter();
        f.Fire();
    }
}