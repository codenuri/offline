﻿using System;
using static System.Console;

// 1. Garbage 가 

class Object
{
    int a, b, c, d;
    public string name = null;
    public static int count = 1;

    public Object(string n) { name = n + ++count;; }

    ~Object() { WriteLine("{0} Destroy", name); }
}

class Program
{
    public static void foo()
    {
        Object o2 = new Object("Object ");
    }
    static void Main(string[] args)
    {
        //Object o1 = new Object("Object ");
        while (true)
        {
            for (int i = 0; i < 1000; i++)
                foo();

            WriteLine(GC.GetTotalMemory(false)); // 현재 메모리 사용량

            ReadLine();
        }


        WriteLine("End Main");       
    }
}


