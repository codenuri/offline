﻿using System;
using static System.Console;

class Fighter
{
    public void Fire() { WriteLine("Fire Missile"); }
}
// cafe.naver.com/codenuri 에서 2일차 사전 소스 받으세요
// Stream2.cs
// 상속을 사용한 기능추가

// 상속 : 클래스에 기능을 추가. 
//        실행시간이 아닌 컴파일 시간에 기능을 추가.
// 상속은 유연성이 없다. 대부분 컴파일시간에 이루어 진다.

class LeftMissile : Fighter
{
    public new void Fire()
    {
        base.Fire(); // 원래의 기능 수행
        WriteLine("Fire Left Missile"); // 새로운 기능추가
    }
}

class Program
{
    static void Main()
    {
        Fighter f = new Fighter();
        f.Fire();

        LeftMissile lm = new LeftMissile();
        lm.Fire();
    }
}