﻿using System;
using System.IO;
using System.Runtime.InteropServices;// windows api 사용하기 위해.
using static System.Console;


// 규칙 1. 반납할 필요가 있는 자원을 사용하는 클래스는
//          Dispose 함수를 제공해야 한다. IDisposal 인테페이스 사용

class MyObject : IDisposable
{
    [DllImport("kernel32.dll")]
    static extern IntPtr CreateEvent(IntPtr lpEventAttributes, bool bManualReset, bool bInitialState, string lpName);
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)] static extern bool CloseHandle(IntPtr hObject);


    public IntPtr apiEvent;
    public FileStream fs = null;


    public bool isDisposed = false;


    public MyObject(string name)
    {
        fs = new FileStream(name, FileMode.OpenOrCreate);

        apiEvent = CreateEvent(new IntPtr(0), false, false, "APIEVENT"); // Win32 Event 객체
    }

    public void Dispose()
    {
        Dispose(true);

        // 사용자가 명시적으로 해지를 한경우 에는 
        // Finalizer를 수행할 필요 없다.
        GC.SuppressFinalize(this);


    //    fs.Dispose();
    //   CloseHandle(apiEvent);
    }
    ~MyObject()
    {
        // Garbage가 수행되므로 fs의 finallizer 가 수행되게 된다.
        // 아래 처럼 닫지 않아도 된다. 오히려 닫으면 2번 Dispose 된다.
        //fs.Dispose();
        //CloseHandle(apiEvent);
        Dispose(false); // 명시적으로 Dispose를 호출한것은 아니다.
    }

    // Dispose 와 Finallyer가 동시에 사용할 자원 해지 함수
    protected void Dispose(bool callDispose )
    {
        if (isDisposed == true)
            return;

        if ( callDispose == true )
        {
            // 사용자가 Dispose 함수를 명시적으로 호출한 경우
            // 관리 자원도 명시적으로 해지 한다.
            fs.Dispose();
        }
        // 비관리 자원. API 함수 호출등으로 얻어낸 자원
        CloseHandle(apiEvent);

        isDisposed = true;
    }
}
// 위처럼 코드를 작성하는 것을 C#에서 "Dispose 패턴" 이라고 합니다.
// Effective C# 17. Dispose 패턴을 사용해라!




class Program
{
    static void Main(string[] args)
    {
        MyObject o = new MyObject("a.txt");

        //o = null;
        //GC.Collect(0);

        o.Dispose();
        o.Dispose();
    }
}

