﻿using System;
using static System.Console;

// weak
class Car
{
    public string name = null;
    public Car(string n) { name = n; }
    ~Car() { WriteLine("{0} Destroy", name); }

    public void Go() { WriteLine("Go"); }
}

class Program
{
    static void Main(string[] args)
    {
        Car c1 = new Car("BMW");
        //Car c2 = c1;

        // root 가 아닌 상태로 객체를 참조하기.
        var c2 = new WeakReference(c1);

        WriteLine(c2.IsAlive); // true
        // c2는 c1객체를 가리키지만 root는 아닙니다.
        // c1이 null 되면 객체는 파괴 됩니다.

        c1 = null;
        GC.Collect();
        GC.WaitForPendingFinalizers();

        WriteLine(c2.IsAlive); // false 

        if (c1 != null) c1.Go();
        //    if (c2 != null) c2.Go();


        /*
        if ( c2.IsAlive ) // 살아 있다면 사용
        {
            //c2로 객체에 접근해도 될까요 ?
        }
        */
        // 위처럼 하지 말고 아래 처럼해야 한다.

        Car c3 = c2.Target as Car;

        if (c3 != null)
        {
            c3.Go();
        }
        else
            WriteLine("객체가 파괴되었습니다.");

        WriteLine("-----------------------");
    }
}





