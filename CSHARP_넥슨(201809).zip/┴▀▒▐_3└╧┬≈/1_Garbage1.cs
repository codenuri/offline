﻿// cafe.naver.com/codenuri   게시판에서
// 3일차 사전소스 받으시면 됩니다.
// "Release" 빌드로 맞춰 주세요.







using System;
using System.IO;
using static System.Console;

class Program
{
    static void Main(string[] args)
    {
        FileStream fs1 = new FileStream("a.txt",
            FileMode.OpenOrCreate, FileAccess.ReadWrite,
            FileShare.None);
        // ......  
        //fs1.Dispose();
        fs1 = null;  // root 변수를 null 로..
        GC.Collect(0); // 이순간 fs1의 finallyzer 실행.
                       // file을 닫는다.
        GC.WaitForPendingFinalizers();

        FileStream fs2 = new FileStream("a.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
    }
}  


