﻿using System;
using System.Collections;
using System.Collections.Generic;
using static System.Console;

// 주제 2. Interface
// 1. 모든 컨테이너는 GetEnumerator() 함수가 있어야 한다
//         : IEnumerable<T> 인터페이스를 구현한다.

// 2. 대부분의 컨테이너는 Count, Add, Remove 등의 있다.
//          : ICollection<T> 인터페이스를 구현한다.

// 3. 일부 컨테이너는 요소가 삽입된 순서(index)로 접근하는 함수가 4개 있다
//          : IList<T> 인터페이스를 구현한다.

class Program
{
    public static void Main()
    {
        List<int> arr = new List<int>() { 1, 2, 3, 4, 5, 6 };

        // arr 의 모든 요소를 열거하고 싶다.
        // 열거자(반복자) : 컨테이너의 모든 요소를 열거하기 위한 객체
        IEnumerator<int> it = arr.GetEnumerator();

        while (it.MoveNext())
        {
            WriteLine(it.Current);
        }

        IEnumerable<int> cont = arr;

        // 대부분 컨테이너는 갯수를 파악할수 있어야 한다.
        WriteLine(arr.Count);

        ICollection<int> cont2 = arr;

        // 인덱서를 사용한 접근
        WriteLine( arr[2] );

        IList<int> cont3 = arr;


        List<int> s1 = new List<int>();

        LinkedList<int> s2 = new LinkedList<int>();
    }
}






