﻿using System;


class Point
{
    public int x;
    public int y;

    public Point(int a = 0, int b = 0) { x = a; y = b; }

}

class Generic1
{
    public static void Main()
    {
        Point p1 = new Point(1, 1);
    }
}
