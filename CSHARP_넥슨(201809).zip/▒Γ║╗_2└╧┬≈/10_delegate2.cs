﻿using System;

// Multicast Delegate
delegate void FP(int a);

class Delegate2
{
    public static void Foo(int a) { Console.WriteLine($"Foo : {a}"); }
    public static void Goo(int a) { Console.WriteLine($"Goo : {a}"); }
    public void Hoo(int a)        { Console.WriteLine($"Hoo : {a}"); }

    public static void Main()
    {
        FP f = Foo;
        f(10);


    }
}