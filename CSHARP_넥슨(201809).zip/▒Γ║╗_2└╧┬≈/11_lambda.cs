﻿using System;

class Labmda1
{
    public static void Main()
    {
        int v1 = 10;

        //Func<int, int, int> plus = (int x, int y) => { return x + y; };
        //Func<int, int, int> plus = (x, y) => { return x + y; };
        //Func<int, int, int> plus = (x, y) => x + y;
        //Func<int, int, int> plus = (x, y) => x + y + v1;

        Func<int, int, int> plus = (x, y) => { v1 = 100; return x + y + v1; };

        Console.WriteLine(plus(1, 2));

        Console.WriteLine(v1);
    }
}