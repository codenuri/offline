﻿using System;

// boxing / unboxing 개념

// 모든 타입의 비교 함수의 이름을 동일하게 할수 있도록 규칙을 만들자

struct Point 
{
    public int x;
    public int y;
    public Point(int a = 0, int b = 0) { x = a; y = b; }
}

class Program
{
    public static void Main()
    {
        int n1 = 0;
        int n2 = 10;

        // C# 에서 객체를 비교하는 2가지 방법
        // 1. 비교 연산자 사용(<, >등)
        // 2. CompareTo() 멤버 함수 사용
        Console.WriteLine(n1 < n2);
        Console.WriteLine(n1.CompareTo(n2));

        Point p1 = new Point(0, 0);
        Point p2 = new Point(1, 1);      
   
    }
}

