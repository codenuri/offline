﻿using System;
//using System.Collections;
using System.Collections.Generic;
using static System.Console;


class Shape
{
    public virtual void Draw() { WriteLine("Shape Draw"); }
}

class Rect : Shape
{
    public override void Draw() { WriteLine("Rect Draw"); }
}

class Circle : Shape
{
    public override void Draw() { WriteLine("Circle Draw"); }
}

class Program
{
    public static void Main()
    {
        List<Shape> arr = new List<Shape>();

        while (true)
        {
            int cmd = int.Parse(ReadLine());

            if (cmd == 1) arr.Add(new Rect());
            else if (cmd == 2) arr.Add(new Circle());
            else if (cmd == 9)
            {
                foreach (var s in arr)
                {
                    s.Draw();
                }
            }
        }
    }
}
