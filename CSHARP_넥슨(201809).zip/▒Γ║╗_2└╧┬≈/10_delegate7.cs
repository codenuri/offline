﻿using System;

// 공변성 ( Covariance ), 반변성 ( contravariance )

delegate TResult MyFunc<out TResult>();
delegate void MyAction<T>(T arg);

class Delegate6
{
    public static Animal F1() { return null; }
    public static Dog F2() { return null; }

    public static void Main()
    {

        MyFunc<Animal> d1 = F1;
        MyFunc<Dog> d2 = F2;

        MyAction<Animal> a1 = F3;
        MyAction<Dog> a2 = F4;





    }

    public static void F3(Animal a) { }
    public static void F4(Dog a) { }
}

class Animal { }
class Dog : Animal { }