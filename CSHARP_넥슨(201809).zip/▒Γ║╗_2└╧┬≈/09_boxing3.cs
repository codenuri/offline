﻿using System;


// object 멤버 Equals        : 인자로 object를 가진다. 값 타입일때 Boxing 발생 
// IEquatable<T> 멤버 Equals : 인자로 T를 가진다.Boxing 없다.

struct Point 
{
    public int x;
    public int y;
    public Point(int a = 0, int b = 0) { x = a; y = b; }
}

class Program
{
    public static void Main()
    {
        Point p1 = new Point(0, 0);
        Point p2 = new Point(0, 1);

        if (p1.Equals(p2))
        {
            Console.WriteLine("Same");
        }
        else
            Console.WriteLine("not Same");

    }
}