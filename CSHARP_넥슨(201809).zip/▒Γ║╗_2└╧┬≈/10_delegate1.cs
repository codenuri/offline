﻿using System;

class Delegate1
{
    public static void Foo(int a) { }

    public static void Main()
    {
        int    n = 10;
        double d = 3.4;

        ? f = Foo;
    }
}