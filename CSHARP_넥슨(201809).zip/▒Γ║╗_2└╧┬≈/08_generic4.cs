﻿using System;

// CRTP

class Singleton
{
    protected static Singleton instance = null;

    public static Singleton getInstance()
    {
        if (instance == null)
            instance = new Singleton();
        return instance;
    }
}

class Generic4
{
    public static void Main()
    {
        Singleton s1 = Singleton.getInstance();
        Singleton s2 = Singleton.getInstance();


    }
}
