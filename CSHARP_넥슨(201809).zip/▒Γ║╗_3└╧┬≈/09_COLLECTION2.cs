﻿using System;
using System.Collections.Generic;       


// Enumerator

class Program
{
    public static void Main()
    {
        LinkedList<int> s = new LinkedList<int>();

        s.AddFirst(10);
        s.AddFirst(20);
        s.AddFirst(30);
        s.AddFirst(40);


    }
}
