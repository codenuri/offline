﻿// Collection1번 복사해 올것
using System;
using System.Collections;         // IEnumerable
using System.Collections.Generic; // IEnumerable<T>
using static System.Console;

class Node<T>
{
    public T data = default(T);
    public Node<T> next = null;

    public Node(T d, Node<T> n) { data = d; next = n; }
}

class MyLinkedList<T> : IEnumerable<T>
{
    // yield 를 사용한 반복자 만들기.
    // 핵심 : 반복자 객체가 없이 그냥 값을 리턴합니다.
    public IEnumerator<T> GetEnumerator()
    {
    }

   
    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }
   
    public Node<T> head = null;

    public void AddFirst(T value)
    {
        head = new Node<T>(value, head);
    }
}

class Program
{
    public static void Main()
    {
        MyLinkedList<int> s = new MyLinkedList<int>();

        s.AddFirst(10);
        s.AddFirst(20);
        s.AddFirst(30);
        s.AddFirst(40);

        IEnumerator<int> it = s.GetEnumerator();
        
        while (it.MoveNext())
        {
            
            Console.WriteLine(it.Current); 
            
        }

    }
}