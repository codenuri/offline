﻿using System;
using System.IO;
using System.IO.Compression;
using static System.Console;

class Program
{
    static void Main()
    {
        FileStream fs = new FileStream("a.txt", FileMode.Create);

        byte[] b = { 65, 66, 67, 68, 69, 0 };
        fs.Write(b, 0, 6);
        fs.Dispose();

    }
}