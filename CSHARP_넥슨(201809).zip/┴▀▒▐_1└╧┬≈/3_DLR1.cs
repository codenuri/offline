﻿using System;
using static System.Console;

// static binding vs dynamic binding
// Dog, object, dynamic
class Dog 
{
    public void Cry() { WriteLine("Dog Cry"); }
}
// static binding : 멤버의 접근(함수 호출등)의 유효성을 
//              컴파일 시간에 조사하는것

// dynamic binding : 멤버의 접근(함수 호출등)의 유효성을  실행시간에 조사
class Program
{
    public static void Main()
    {
        //Dog a = new Dog();
        //object a = new Dog(); // ok. 모든 클래스의 기반 클래스

        dynamic a = new Dog();
        a.Cry();
        a.foo(); // 컴파일 ok. 실행시간에 예외 발생.
  
    }
}