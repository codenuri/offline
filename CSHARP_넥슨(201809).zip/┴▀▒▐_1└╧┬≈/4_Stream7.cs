﻿// backing store
// 1. FileStream
// 2. IsolatedStorageStream
// 3. MemoryStream
// 4. NetworkStream

// Stream Decorator
// 1. DeflateStream
// 2. GZipStream
// 3. CryptoStream
// 4. BufferedStream

// Stream Adaptor
// 1. StreamReader / StreamWriter
// 2. BinaryReader / BinaryWriter
// 3. XmlReader / XmlWriter
