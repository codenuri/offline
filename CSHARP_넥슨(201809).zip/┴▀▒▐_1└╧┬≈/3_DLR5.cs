﻿using System;
using System.Collections;
using System.Collections.Generic;
using static System.Console;

class Animal
{
    public virtual void Fight() { WriteLine("Animal Fight");  }
}
class Dog : Animal
{
    public override void Fight() { WriteLine("Dog Fight"); }
}
class Cat : Animal
{
    public override void Fight() { WriteLine("Cat Fight"); }
}

class Program
{
    public static void Main()
    {
        Animal[] arr = new Animal[10];

        arr[0] = new Dog();
        arr[1] = new Cat();

        arr[0].Fight();
        arr[1].Fight();
    }
}


