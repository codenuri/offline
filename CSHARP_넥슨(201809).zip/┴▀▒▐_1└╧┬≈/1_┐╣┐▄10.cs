﻿using System;
using static System.Console;

// 주제 10. Exception Safety(예외 안정성)

// 1. 완전보장 : 예외가 없다.
// 2. 기본보장 : 예외가 나와도, 잡으면 ,자원누수가 없고, 
//            객체의 상태는 유효해야 한다.

// 3. 강력보장 : 기본 보장을 만족하고
//              객체의 상태는 예외 발생이전을 유지해야 한다.


class StackUnderflowException : Exception { }

class Stack
{
    int idx = 0;
    int[] arr = new int[10];

    public void push(int a)
    {
        arr[idx++] = a;
    }
    public int pop()
    {
        if (idx < 1)
            throw new StackUnderflowException();

        --idx;


        return arr[idx];
    }
}
class Program
{
    static void Main()
    {
        Stack s = new Stack();
        try
        {
            int n = s.pop();
        }
        catch (StackUnderflowException e) { }

        WriteLine("계속 실행");
        s.push(10); // 될까요 ?
    }
}

