﻿using System;
using static System.Console;

class Fighter
{
    public void Fire() { WriteLine("Fire Missile"); }
}

class Program
{
    static void Main()
    {
        Fighter f = new Fighter();
        f.Fire();
    }
}