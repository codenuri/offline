﻿using System;
using System.Collections.Generic;
using static System.Console;

// 전통적인 객체지향 디자인 
// 가상함수의 추가         : 어렵다
// 새로운 요소(도형)의 추가 : 쉽다.

// 방문자 패턴 : 가상함수 추가를 쉽게하고, 새로운 요소의 추가를 어렵게
//              하는 패턴.

class Shape
{
    public virtual void Draw() { WriteLine("Shape Draw"); }
    // 가상함수 Move를 추가하고 싶다. =>  쉬운작업 ? 어려운작업?
}
class Point : Shape
{
    public int x = 0;
    public int y = 0;
    public Point(int a = 0, int b = 0) { x = a; y = b; }
    public override void Draw() { WriteLine("Point Draw"); }
}
class Circle : Shape
{
    public int radius = 0;
    public Circle(int r = 0) { radius = r; }
    public override void Draw() { WriteLine("Circle Draw"); }
}

class Sheet
{
    List<Shape> st = new List<Shape>();

    public void Append(Shape s) { st.Add(s); }
}

class Program
{
    public static void Main()
    {
        Sheet s = new Sheet();
        s.Append(new Point(10, 10));
        s.Append(new Circle(5));
    }
}