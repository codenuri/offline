﻿using System;
using System.Net;
using static System.Console;

// 

class Program
{
    static void Main()
    {
        string s = null;

        WebClient wc = new WebClient();
        s = wc.DownloadString("http://wwww.naver.com");
        WriteLine(s);
        wc.Dispose();
    }
}