﻿using System;
using static System.Console;

// 주제 3. Exception 주요 멤버 ( Message, Source, StackTrace)
// 

class Program
{
    static void Main()
    {
        string s = "a";
        try
        {
            int n = int.Parse(s);
            WriteLine(n);
        }
        catch (Exception e)
        {
            WriteLine(e.Message); // 설명
            WriteLine(e.Source);  // 예외가 나온 assemly와 함수
            WriteLine(e.StackTrace); // call stack

        }


        WriteLine("프로그램은 계속 수행될수 있음");
    }
}