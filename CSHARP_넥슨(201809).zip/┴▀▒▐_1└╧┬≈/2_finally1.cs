﻿using System;
using System.IO;
using static System.Console;

// catch : 예외 발생시만 실행
// finally : try 블럭을 벗어날때 항상 실행
class Test
{
    static int foo()
    {
        int temp = 10;
        try
        {
            //....
        }  
        catch( Exception e)
        {
        }
        return  temp;
    }
    static void Main()
    {
        foo();
    }
}