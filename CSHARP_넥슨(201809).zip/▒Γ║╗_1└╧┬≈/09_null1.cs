﻿using System;

// null1.cs

// ?? : 널 접합 연산자(null-coalescing operator)
// ?  : 널 조건부 연산자(null-conditional operator, 'Elvis' operator)

class Car
{
    public void Go() { Console.WriteLine("Car Go"); }
}

class Program
{
    public static Car CreateCar(int speed)
    {
        if (speed < 200)
            return new Car();
        return null;
    }
    public static void Main()
    {
        Car c = CreateCar(100);

        c.Go();
    }
}

