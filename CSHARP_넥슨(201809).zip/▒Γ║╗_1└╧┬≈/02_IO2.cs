﻿
using System; // namespace 이름없이 클래스 사용
using static System.Console; // 클래스 이름없이 static 함수를 사용하고
                            // 싶을때.

class Program
{
    public static void Main()
    {
        Console.WriteLine("Hello C#");

        WriteLine("Hello C#");
    }
}