﻿using System;

// 식본문 메소드(expression-bodied method)

class Program
{
    public static int square1(int x) { return x * x; }

    public static void Main()
    {
        Console.WriteLine(square1(3));
    }

}