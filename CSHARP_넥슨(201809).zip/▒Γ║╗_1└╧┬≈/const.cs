﻿using System;

// csc const.cs /target:library

public class Const
{
    public const int const_value = 10;
    public static readonly int readonly_value = 10;
}

