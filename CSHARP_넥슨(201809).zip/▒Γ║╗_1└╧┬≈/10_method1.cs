﻿using System;

// 2. 인자 전달 방식과 참조 타입

class Point
{
    public int x = 0;
    public int y = 0;

    public Point(int a, int b) { x = a; y = b; }
}

class Program
{
    public static void f1(Point p) { p.x = 10; }
    public static void f2(ref Point p) { p.x = 10; }

    public static void Main()
    {
        Point p1 = new Point(0, 0);
        f1(p1);

        Console.WriteLine($"{p1.x}, {p2.x}");
    }

    public static void f3(Point p) { p = new Point(1, 1); }
    public static void f4(ref Point p) { p = new Point(1, 1); }

}