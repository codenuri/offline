﻿using System;

// 생성자 호출 순서
class BM { public BM() { Console.WriteLine("BM()"); } }
class DM { public DM() { Console.WriteLine("DM()"); } }

class Base
{
    public int data = BaseFieldInit();
    public BM bm = new BM();
    protected Base() { Console.WriteLine("Base()"); }

    public static int BaseFieldInit() { Console.WriteLine("BaseFieldInit"); return 0; }
}

class Derived : Base
{
    public int data = DerivedFieldInit();
    public DM dm = new DM();
    public Derived() { Console.WriteLine("Derived()"); }

    
    public static int DerivedFieldInit() { Console.WriteLine("DerivedFieldInit"); return 0; }
}


class Program
{
    public static void Main()
    {
        Derived d = new Derived();
    }
}