﻿using System;

// var

class Program
{
    public static void Main()
    {
        double n1 = 10;
        //int n2 = n1;

        var n2 = n1; // 우측 표현식과 동일한 변수 n2 만들기





    }
}