﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAY1
{
    class _10_method2
    {
    }
}
