﻿using System;

// 주제 : property
// ildasm 으로 확인
// 1. 사용시에는 필드처럼 보이지만 구현시에는 메서드 처럼 만드는 코드.

class Bike
{
    public int gear = 0;
         

}

class Program
{
    public static void Main()
    {
        Bike b = new Bike();
        b.gear = -10;
        Console.WriteLine(b.gear);

    }
}

