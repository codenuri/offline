﻿using System.Windows;
using System.Drawing;

namespace TEMPLATE
{    public class MainWindowViewModel : ObservableObject
    {
        private Random random;

        private List<string> _colors;
        public List<string> Colors 
        {
            get => _colors;
            set
            {
                _colors = value;
                OnPropertyChanged();
            }
        }

        public MainWindowViewModel()
        {
            random = new();
            _colors = new();
            SetRandomColors();
        }

        private void SetRandomColors()
        {
            for (int i = 0; i < 10; i++)
            {
                Color randomColor = Color.FromArgb(random.Next(256), random.Next(256), random.Next(256));
                Colors.Add(randomColor.ToString());
            }
        }
    }

}
