﻿using System;
using System.Media;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Xps.Serialization;

// 5. 자료구조 도입

public class MainWindow : System.Windows.Window
{
    private const int COUNT = 5;
    private const int EMPTY = COUNT * COUNT - 1;

    private BitmapImage bitmap = new BitmapImage(new Uri("A:\\totoro.jpg"));
    private Grid grid = new Grid();
    private int[,] board = new int[COUNT, COUNT];

    private void InitGame()
    {
        Width = 800;
        Height = 600;

        for (int i = 0; i < 5; ++i)
        {
            grid.RowDefinitions.Add(new RowDefinition());
            grid.ColumnDefinitions.Add(new ColumnDefinition());
        }

        this.Content = grid;
    }

    public void InitBoard()
    {
        for (int y = 0; y < COUNT; y++)
        {
            for (int x = 0; x < COUNT; x++)
            {
                board[y, x] = y * COUNT + x;
            }
        }
    }


    public void DrawGame()
    {
        int w = (int)(bitmap.Width / COUNT);
        int h = (int)(bitmap.Height / COUNT);

        for (int y = 0; y < 5; ++y)
        {
            for (int x = 0; x < 5; ++x)
            {

                if (board[y, x] != EMPTY)
                {
                    int no = board[y, x];
                    int bx = no % COUNT;
                    int by = no / COUNT;

                    CroppedBitmap block_bitmap = new CroppedBitmap(bitmap, new Int32Rect(bx * w, by * h, w, h));

                    Image img = new Image { Source = block_bitmap };
                    img.Stretch = Stretch.Fill;
                    img.Margin = new Thickness(0.5);

                    Grid.SetRow(img, y);
                    Grid.SetColumn(img, x);

                    grid.Children.Add(img);
                }
            }
        }

    }
    protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
    {
        base.OnMouseLeftButtonDown(e);

        //Point pt = e.GetPosition(this); // MainWindow 기준 좌표
        Point pt = e.GetPosition(grid);

        int bx = (int)(pt.X / (grid.ActualWidth / COUNT));
        int by = (int)(pt.Y / (grid.ActualHeight / COUNT));

        if (bx < 0 || by < 0 || bx >= COUNT || by >= COUNT) return;

        // 상하좌우 조사
        if (bx < COUNT - 1 && board[by, bx + 1] == EMPTY) // RIGHT 가 empty
        {
            SwapBlock(bx, by, bx + 1, by);
        }
        else if (bx > 0 && board[by, bx - 1] == EMPTY) // Left 가 empty
        {
            SwapBlock(bx, by, bx - 1, by);
        }
        else if (by < COUNT - 1 && board[by + 1, bx] == EMPTY)
        {
            SwapBlock(bx, by, bx, by + 1);
        }
        else if (by > 0 && board[by - 1, bx] == EMPTY)
        {
            SwapBlock(bx, by, bx, by - 1);
        }
        else
        {
            SystemSounds.Beep.Play();
            return;
        }
        // 다 맞추었는지 확인
    }

    public void SwapBlock(int x1, int y1, int x2, int y2)
    {
        // 배열값 교환
        int temp = board[y1, x1];
        board[y1, x1] = board[y2, x2];
        board[y2, x2] = temp;
            

        // grid내부의 image 교환
        Image img1 = grid.Children.Cast<Image>().FirstOrDefault( n => Grid.GetRow(n) == y1 && Grid.GetColumn(n) == x1 );
        Image img2 = grid.Children.Cast<Image>().FirstOrDefault( n => Grid.GetRow(n) == y2 && Grid.GetColumn(n) == x2 );

        if (img1 != null)
        {
            Grid.SetRow(img1, y2);
            Grid.SetColumn(img1, x2);
        }

        if (img2 != null)
        {
            Grid.SetRow(img2, y1);
            Grid.SetColumn(img2, x1);
        }
    }

    public MainWindow()
    {
        InitBoard();
        InitGame();
        DrawGame();
    }
}

public class App : System.Windows.Application
{

    [STAThread]
    public static void Main()
    {
        App app = new App();

        MainWindow win = new MainWindow();

        app.Run(win);
    }
}
