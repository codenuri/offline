﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

// 핵심 : Layout 의 Child 에 등록하려면 "UIElement" 로 부터 파생 되어야 한다.

public class MainWindow : System.Windows.Window
{
    public MainWindow()
    {
        Grid g = new Grid();

        this.Content = g;
        //=================================
        // #1. row, col 지정 : 2 * 2
        g.RowDefinitions.Add(new RowDefinition());
        g.RowDefinitions.Add(new RowDefinition());

        g.ColumnDefinitions.Add(new ColumnDefinition());
        g.ColumnDefinitions.Add(new ColumnDefinition());

        //==================================
        Button b1 = new Button { Content = "button1" };
        Button b2 = new Button { Content = "button2" };
        Button b3 = new Button { Content = "button3" };
        Button b4 = new Button { Content = "button4" };

        //==================================
        g.Children.Add(b1);
        g.Children.Add(b2);
        g.Children.Add(b3);
        g.Children.Add(b4);

        //===================================
        Grid.SetRow(b1, 0); Grid.SetColumn(b1, 0);
        Grid.SetRow(b2, 0); Grid.SetColumn(b2, 1);
        Grid.SetRow(b3, 1); Grid.SetColumn(b3, 0);
        Grid.SetRow(b4, 1); Grid.SetColumn(b4, 1);

    }
}

public class App : System.Windows.Application
{
    public App()
    {
    }

    [STAThread]
    public static void Main()
    {
        App app = new App();

        MainWindow win = new MainWindow();

        app.Run(win);
    }
}
