﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Xps.Serialization;

// 3. grid 만들고, grid 0, 0 에 출력

public class MainWindow : System.Windows.Window
{
    private BitmapImage bitmap = new BitmapImage(new Uri("A:\\totoro.jpg"));
    private Grid grid = new Grid();
    private const int COUNT = 5;

    private void InitGame()
    {
        Width = 800;
        Height = 600;

        for (int i = 0; i < 5; ++i)
        {
            grid.RowDefinitions.Add(new RowDefinition());
            grid.ColumnDefinitions.Add(new ColumnDefinition());
        }

        this.Content = grid;
    }
    public void DrawGame()
    {
        int w = (int)(bitmap.Width / COUNT);
        int h = (int)(bitmap.Height / COUNT);

        CroppedBitmap block_bitmap = new CroppedBitmap(bitmap, new Int32Rect(0, 0, w, h));

        Image img = new Image { Source = block_bitmap };
        img.Stretch = Stretch.Fill;

        Grid.SetRow(img, 0);
        Grid.SetColumn(img, 0);

        grid.Children.Add(img);        
    }

    public MainWindow()
    {
        InitGame();
        DrawGame();
    }
}

public class App : System.Windows.Application
{

    [STAThread]
    public static void Main()
    {
        App app = new App();

        MainWindow win = new MainWindow();

        app.Run(win);
    }
}
