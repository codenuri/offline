﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

// 핵심 : Layout 의 Child 에 등록하려면 "UIElement" 로 부터 파생 되어야 한다.

public class MainWindow : System.Windows.Window
{
    public MainWindow()
    {
        StackPanel sp = new StackPanel();

        Content = sp;

        Button btn = new Button();
        btn.Content = "button1";

        sp.Children.Add(btn);

        Image img = new Image();
        img.Source = new BitmapImage(new Uri("E:\\pic.png"));

        sp.Children.Add(img);

        //      sp.Children.Add("hello");
        sp.Children.Add(new Label { Content = "hello" });
    }
}

public class App : System.Windows.Application
{
    public App()
    {
    }

    [STAThread]
    public static void Main()
    {
        App app = new App();

        MainWindow win = new MainWindow();

        app.Run(win);
    }
}
