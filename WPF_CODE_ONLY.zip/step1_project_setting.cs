﻿using System;
using System.Windows;

class Program
{
    public static void Main()
    {
        MessageBox.Show("Hello, WPF");
    }
}
