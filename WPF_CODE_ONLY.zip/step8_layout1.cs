﻿using System;
using System.Windows;
using System.Windows.Controls;

public class MainWindow : System.Windows.Window
{
    public MainWindow()
    {
//      Content = "hello";

        StackPanel sp = new StackPanel();

        Content = sp;

        Button btn1 = new Button();
        Button btn2 = new Button();

        btn1.Content = "button1";
        btn2.Content = "button2";

        sp.Children.Add(btn1);
        sp.Children.Add(btn2);

        //      sp.Orientation = Orientation.Vertical;
        sp.Orientation = Orientation.Horizontal;
    }
}

public class App : System.Windows.Application
{
    public App()
    {
    }

    [STAThread]
    public static void Main()
    {
        App app = new App();

        MainWindow win = new MainWindow();

        app.Run(win);
    }
}
