﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Xps.Serialization;

// 1. Image 출력

public class MainWindow : System.Windows.Window
{
    private BitmapImage bitmap = new BitmapImage(new Uri("A:\\totoro.jpg"));

    public void DrawGame()
    {
        Image img = new Image { Source = bitmap };
        this.Content = img;
    }

    public MainWindow()
    {
        Width = 800;
        Height = 600;

        DrawGame();
    }
}

public class App : System.Windows.Application
{

    [STAThread]
    public static void Main()
    {
        App app = new App();

        MainWindow win = new MainWindow();

        app.Run(win);
    }
}
