﻿using System;
using System.Windows;
using System.Windows.Media;

public class MainWindow : System.Windows.Window
{
    public MainWindow()
    {
        Title = "Step7";
        Width = 400;
        Height = 400;        
        Topmost = true;
        Background = new SolidColorBrush(Colors.Green);
    }
}

public class App : System.Windows.Application
{
    public App()
    {
    }

    [STAThread]
    public static void Main()
    {
        App app = new App();

        MainWindow win = new MainWindow();

        app.Run(win);
    }
}
