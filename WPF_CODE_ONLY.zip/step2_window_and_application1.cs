﻿using System;
using System.Windows;

class Program
{
    [STAThread]
    public static void Main()
    {
        Window win = new Window();
        win.Show();
        MessageBox.Show("Hello, WPF");
    }
}
