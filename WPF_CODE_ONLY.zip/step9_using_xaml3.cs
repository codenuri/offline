﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace AAA
{
    public class MainWindow : System.Windows.Window
    {
        public MainWindow()
        {
        }
    }

    public class App : System.Windows.Application
    {
        public App()
        {
        }

        [STAThread]
        public static void Main()
        {
            App app = new App();

            //MainWindow win = null!;
            //MainWindow win = new MainWindow();

            Window win = null;

            using (FileStream fs = new FileStream("../../../step9_using_xaml3.xaml", FileMode.Open))
            {
                win = (Window)XamlReader.Load(fs);
            }
            

            app.Run(win);
        }
    }
}