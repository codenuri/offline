﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

public class MainWindow : System.Windows.Window
{
    public MainWindow()
    {
        // #1. string
        //      Content = "Hello";

        // #2. bitmap
        //      BitmapImage bitmap = new BitmapImage(  new Uri("E:\\pic.png"));

        //      Image img = new Image();
        //      img.Source = new BitmapImage(new Uri("E:\\pic.png"));
        //      Content = img;

        // #3. Control
        //        Button btn = new Button();
        //        btn.Content = "Ok";
        //        Content = btn;

        Content = new Button { Content = "OK" };     
    }
}

public class App : System.Windows.Application
{
    public App()
    {
    }

    [STAThread]
    public static void Main()
    {
        App app = new App();

        MainWindow win = new MainWindow();

        app.Run(win);
    }
}
