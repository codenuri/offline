﻿using System;
using System.Windows;
using System.Windows.Input;

public class MainWindow : System.Windows.Window
{
    public MainWindow()
    {
        this.MouseDown += MainWindow_MouseDown;
    }

    public void MainWindow_MouseDown(object sender, MouseButtonEventArgs e)
    {
        //      Application.Current.Shutdown(0);
        ((App)Application.Current).Fn();
    }
}

public class App : System.Windows.Application
{
    public void Fn()
    {
        MessageBox.Show("App Fn");
    }

    [STAThread]
    public static void Main()
    {
        App app = new App();

        MainWindow win = new MainWindow();

        app.Run(win);
    }
}
