﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

public class MainWindow : System.Windows.Window
{
    protected void InitializeComponent()
    {
        StackPanel sp = null!;

        using (FileStream fs = new FileStream("../../../step9_using_xaml1.xaml", FileMode.Open))
        {
            sp = (StackPanel)XamlReader.Load(fs);
        }

        this.Content = sp;

        Button btn = (Button)sp.FindName("button1");
    }

    public MainWindow()
    {
        InitializeComponent();
    }
}

public class App : System.Windows.Application
{
    public App()
    {
    }

    [STAThread]
    public static void Main()
    {
        App app = new App();

        MainWindow win = new MainWindow();

        app.Run(win);
    }
}
