﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

public class MainWindow : System.Windows.Window
{
    protected void InitializeComponent()
    {
        Title = "MainWindow";
    }

    public MainWindow()
    {
        InitializeComponent();
    }
}

public class App : System.Windows.Application
{
    public App()
    {
    }

    [STAThread]
    public static void Main()
    {
        App app = new App();

        Window win = null;

        using (FileStream fs = new FileStream("../../../step9_using_xaml2.xaml", FileMode.Open))
        {
            win = (Window)XamlReader.Load(fs);
        }

        app.Run(win);
    }
}
