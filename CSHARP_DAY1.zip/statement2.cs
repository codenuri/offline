int Foo()
{
	int n;

	n = 3;

	if ( n == 3 )
	{
		int a = 0;
		a = 10;
	}

	return 0;
}
