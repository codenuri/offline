using System;
using static System.Console;

// 2030-1-1 9:30:10
DateTime tm = new DateTime(2030, 1, 1, 9, 30, 10);


int    n1 = new int();
string s1 = new string("ABCD")


int    n2 = 0;
string s2 = "ABCD";
