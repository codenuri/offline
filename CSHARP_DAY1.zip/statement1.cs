void Foo()
{
	int n; 	// declaration statement

	n = 3;	// expression statement
}
