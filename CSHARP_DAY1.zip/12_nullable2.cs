string s1 = "hello";
string s2 = null;	// ok

int n1 = 0;
//int n2 = null;	// error

Nullable<int>    n3 = null;
//Nullable<string> s3 = null;// error

int? n4 = null;	








