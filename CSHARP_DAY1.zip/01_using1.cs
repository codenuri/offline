using System;

Console.Write("Hello, ");
Console.WriteLine("C#");

