using System;

int n1 = 10;

string s1 = n1.ToString();
string s2 = 10.ToString();

int n2 = int.Parse(s2);
