// 변수의 초기값을 지정하는 방법.

int n1;		// 초기화 안됨.

int n2 = 0;
int n3 = new int();

int n4 = default(int); // int n4 = 0;
int n5 = default;	   // int n5 = 0;

var v1 = default(int); // int v1 = 0;
var v2 = default;	   // error

