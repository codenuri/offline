﻿// 1. singleton
// 2. builder
// 3. prototype
// 4. abstract factory
// 5. factory method

// 6. composite
// 7. decorator
using System;
using System.Collections.Generic;
using System.Transactions;
using static System.Console;

abstract class Handler
{
    public Handler Next { set; get; } = null;
    public Handler SetNext(Handler n)
    {
        Next = n;
        return Next;
    }
    public void Handle(int problem)
    {
        if (Resolve(problem))
            return;

        if (Next != null)
            Next.Handle(problem);
    }
    public abstract bool Resolve(int problem);
}

class Team1 : Handler
{
    public override bool Resolve(int problem)
    {
        WriteLine("Team1 Start");

        if (problem == 7)
        {
            WriteLine("Resolved by Team1");
            return true;
        }
        return false;
    }
}
class Team2 : Handler
{
    public override bool Resolve(int problem)
    {
        WriteLine("Team2 Start");

        if (problem % 2 == 0)
        {
            WriteLine("Resolved by Team2");
            return true;
        }
        return false;
    }
}

class Team3 : Handler
{
    public override bool Resolve(int problem)
    {
        WriteLine("Team3 Start");

        if (problem > 10)
        {
            WriteLine("Resolved by Team3");
            return true;
        }
        return false;
    }
}

class Program
{
    static void Main(string[] args)
    {
        Team1 t1 = new Team1();
        t1.SetNext(new Team2()).SetNext(new Team3());

        // t1 => t2 => t3
        // t1.Handle(7);
        // t1.Handle(4);
        // t1.Handle(13);
        t1.Handle(3);
    }
}

