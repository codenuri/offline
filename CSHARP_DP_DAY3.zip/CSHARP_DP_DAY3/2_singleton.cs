﻿using System;
using System.Collections.Generic;
using static System.Console;

class Cursor
{
    private Cursor() { WriteLine("Cursor()"); }

    public static Cursor Instance { get; } = new Cursor();
}

class Program
{
    static void Main(string[] args)
    {
        Cursor c1 = Cursor.Instance;
        Cursor c2 = Cursor.Instance;

    }
}

