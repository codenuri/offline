﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Dynamic;
using static System.Console;

class Color
{
    public Color(int red, int green, int blue) { }
}

class Colors
{
    public static Color Red { get; } = new Color(255, 0, 0);
    public static Color Green { get; } = new Color(0, 255, 0);
    public static Color Blue { get; } = new Color(0, 0, 255);
}

class Program
{
    public static void Main()
    {
        SetColor(Colors.Red);
        SetColor(Colors.Green);
        SetColor(Colors.Blue);
    }
    public static void SetColor(Color c)
    {

    }
}



