﻿using System;
using System.Collections.Generic;
using System.Threading;
using static System.Console;

using Character = string; // class Character {} 라고 가정

interface IBuilder
{
    void MakeHat();
    void MakeUniform();
    void MakeShoes();

    String GetResult();
}

class Director
{
    public IBuilder Builder { set; get; } = null;

    public Character MakeCharacter()
    {
        Builder?.MakeHat();
        Builder?.MakeUniform();
        Builder?.MakeShoes();

        return Builder?.GetResult();
    }
}

class Korean : IBuilder
{
    public Character c = null;

    public void MakeHat() { c += "갓\n"; }
    public void MakeUniform() { c += "한복\n"; }
    public void MakeShoes() { c += "짚신\n"; }

    public String GetResult() { return c; }
}

class American : IBuilder
{
    public Character c = null;

    public void MakeHat() { c += "야구모자\n"; }
    public void MakeUniform() { c += "양복\n"; }
    public void MakeShoes() { c += "구두\n"; }

    public String GetResult() { return c; }
}

class Program
{
    public static void Main()
    {
        Director d = new Director();
        //      d.Builder = new Korean();
        d.Builder = new American();

        Character c = d.MakeCharacter();

        WriteLine(c);

    }
}


