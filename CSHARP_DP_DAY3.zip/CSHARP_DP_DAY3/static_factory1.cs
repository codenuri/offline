﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using static System.Console;

class Color
{
    public Color(int red, int green, int blue) { }
}

class Program
{
    public static void Main()
    {
        // SetColor 메소드에 빨간색, 파란색, 흰색을 보내 보세요
        SetColor( ? );
        SetColor( ? );
        SetColor( ? );
    }
    public static void SetColor(Color c)
    {

    }
}



