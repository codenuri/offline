﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using static System.Console;


class MyCollection<T>
{
    public delegate void FUNC1(T a);
    public delegate void FUNC2(ref T a);
    public delegate void FUNC3(out T a);

    public List<T> c = new List<T>();

    public void Add(T e) { c.Add(e); }

    public void Accept(FUNC1 f1)
    {
        for (int i = 0; i < c.Count; i++)
            f1(c[i]);
    }

    public void Accept(FUNC2 f2)
    {
        Span<T> span = CollectionsMarshal.AsSpan(c);

        for (int i = 0; i < c.Count; i++)
            f2(ref span[i]);
    }
    public void Accept(FUNC3 f3)
    {
        Span<T> span = CollectionsMarshal.AsSpan(c);

        for (int i = 0; i < c.Count; i++)
            f3(out span[i]);
    }
}


class Program
{
    public static void Main(string[] args)
    {
        MyCollection<int> c = new MyCollection<int>();

        for (int i = 0; i < 10; i++)
            c.Add(i);

        c.Accept((ref int e) => e *= 2);

        c.Accept((int e) => Write($"{e}, "));
    }
}



