﻿using System;
using System.Collections.Generic;
using System.Threading;
using static System.Console;

class Image
{
    private string url;

    public Image(string u)
    {
        url = u;
        WriteLine($"Download... {url}");
        Thread.Sleep(3000);
    }

    public void Draw()
    {
        WriteLine($"Draw {url}");
    }
}
class Program
{
    public static void Main()
    {
        Image img1 = new Image("www.image.com/car.png");
        img1.Draw();

        Image img2 = new Image("www.image.com/car.png");
        img2.Draw();

    }
}


