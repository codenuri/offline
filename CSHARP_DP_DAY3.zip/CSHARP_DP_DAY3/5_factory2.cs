﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using static System.Console;


public interface IFactoryRegister { }

class Rect : IFactoryRegister
{
    static Rect() { WriteLine("static Rect"); }
}

public static class FactoryInitializer
{
    public static void InitializeAllRegistrations()
    {
        // 예를 들어, IFactoryRegister 인터페이스를 구현한 타입들을 강제 초기화
        var types = Assembly.GetExecutingAssembly().GetTypes()
                            .Where(t => typeof(IFactoryRegister).IsAssignableFrom(t) && !t.IsInterface);
        foreach (var type in types)
        {
            // static constructor 강제 실행
            RuntimeHelpers.RunClassConstructor(type.TypeHandle);
        }
    }
}


class Program
{
    public static void Main()
    {
        RuntimeHelpers.RunClassConstructor(typeof(Rect).TypeHandle);
    }
}



