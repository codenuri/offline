﻿// 6. composite
// 7. decorator
// 8. adapter
// 9. proxy
// 13. template method
// 14. strategy
// 15. state
// 18. command
// 11. facade
// 23. interpret
//-----------------------------------------



// 1. singleton
// 2. builder
// 3. prototype
// 4. abstract factory
// 5. factory method

// 10. bridge
// 12. flyweight

// 16. observer
// 17. chain of responsibility
// 19. iterator
// 20. visitor
// 21. memento
// 22. mediator
