﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using static System.Console;

interface IButton { void Draw(); }
interface IEdit { void Draw(); }

class WinButton : IButton
{
    public void Draw() { WriteLine("Draw WinButton"); }
}
class WinEdit : IEdit
{
    public void Draw() { WriteLine("Draw WinEdit"); }
}

class OsxButton : IButton
{
    public void Draw() { WriteLine("Draw OsxButton"); }
}


class OsxEdit : IEdit
{
    public void Draw()
    {
        WriteLine("Draw OsxEdit");
    }
}

class WinDialog
{
    public void Init()
    {
        IButton btn = new WinButton();
        IEdit edit = new WinEdit();

        btn.Draw();
        edit.Draw();
    }
}

class OsxDialog
{
    public void Init()
    {
        IButton btn = new OsxButton();
        IEdit edit = new OsxEdit();

        btn.Draw();
        edit.Draw();
    }
}

class Program
{
    public static void Main(string[] args)
    {
        WinDialog dlg1 = new WinDialog();
        OsxDialog dlg2 = new OsxDialog();

        dlg1.Init();
        dlg2.Init();
    }
}



