﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using static System.Console;

interface IButton
{
    void Draw();
}
interface IEdit
{
    void Draw();
}

class WinButton : IButton
{
    public void Draw() { WriteLine("Draw WinButton"); }
}
class WinEdit : IEdit
{
    public void Draw() { WriteLine("Draw WinEdit"); }
}

class OsxButton : IButton
{
    public void Draw() { WriteLine("Draw OsxButton"); }
}


class OsxEdit : IEdit
{
    public void Draw()
    {
        WriteLine("Draw OsxEdit");
    }
}
//-----------------------------------
class WinFactory
{
    public IButton CreateButton() { return new WinButton(); }
    public IEdit CreateEdit() { return new WinEdit(); }
}
class OsxFactory
{
    public IButton CreateButton() { return new OsxButton(); }
    public IEdit CreateEdit() { return new OsxEdit(); }
}

class Program
{
    public static void Main(string[] args)
    {
        ? btn = null;

        int style = 0;

        if (style == 1)
            btn = new WinButton();
        else
            btn = new OsxButton();

    }
}



