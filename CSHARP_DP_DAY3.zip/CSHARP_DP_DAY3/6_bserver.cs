﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using static System.Console;

interface IGraph
{
    void Update(int n);
}

class Subject
{
    private List<IGraph> c = new List<IGraph>();

    public void Attach(IGraph g) { c.Add(g); }
    public void Detach(IGraph g) { c.Remove(g); }
    public void Notify(int data)
    {
        foreach (var g in c)
            g.Update(data);
    }
}

class Table : Subject
{
    private int data;
    public void Edit()
    {
        while (true)
        {
            data = int.Parse(ReadLine());

            Notify(data);
        }
    }
}

class PieGraph : IGraph
{
    public void Update(int n)
    {
        Write("PieGraph : ");

        for (int i = 0; i < n; i++)
            Write(")");
        WriteLine();
    }
}
class BarGraph : IGraph
{
    public void Update(int n)
    {
        Write("BarGraph : ");

        for (int i = 0; i < n; i++)
            Write("|");
        WriteLine();
    }
}

class Program
{
    public static void Main(string[] args)
    {
        Table t = new Table();

        t.Attach(new PieGraph());
        t.Attach(new BarGraph());

        t.Edit();
    }
}



