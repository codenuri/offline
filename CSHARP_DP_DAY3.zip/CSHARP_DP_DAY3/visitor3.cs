﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using static System.Console;

interface IVisitor
{
    public void Visit(ref int e);
}
class TwiceVisitor : IVisitor
{
    public void Visit(ref int e) { e *= 2; }
}
class ShowVisitor : IVisitor
{
    public void Visit(ref int e) { WriteLine($"{e}"); }
}

class MyCollection
{
    public List<int> c = new List<int>();

    public void Add(int e) { c.Add(e); }

    public void Accept(IVisitor visitor)
    {
        Span<int> span = CollectionsMarshal.AsSpan(c);

        for (int i = 0; i < c.Count; i++)
        {
            visitor.Visit(ref span[i]);
        }
    }
}


class Program
{
    public static void Main(string[] args)
    {
        MyCollection c = new MyCollection();

        for (int i = 0; i < 10; i++)
            c.Add(i);

        c.Accept(new TwiceVisitor());
        c.Accept(new ShowVisitor());
    }
}



