using System;
using System.Collections.Generic;
using static System.Console;

class Shape
{
	public int Color { set; get; } = 0;

	public virtual void Draw() { WriteLine("Draw Shape"); }
}




class Rect : Shape
{
	public override void Draw() { WriteLine("Draw Rect"); }
	public static Shape Create() { return new Rect(); }
}

class Circle : Shape
{
	public override void Draw() { WriteLine("Draw Circle"); }

	public static Shape Create() { return new Circle(); }
}

class Factory
{
	public delegate Shape CREATOR();

	private Dictionary<int, CREATOR> d = new Dictionary<int, CREATOR>();

	public void Register(int key, CREATOR c)
	{
		d[key] = c;
	}
	public Shape Create(int key)
	{
		Shape s = null;

		if (d.ContainsKey(key))
		{
			s = d[key]();
		}
		return s;
	}
}


class Program
{
	public static void Main()
	{
		List<Shape> c = new List<Shape>();

		Factory f = new Factory();

		f.Register(1, Rect.Create);
		f.Register(2, Circle.Create);

		while (true)
		{
			int cmd = int.Parse(ReadLine());

			if (cmd >= 1 && cmd <= 7)
			{
				Shape s = f.Create(cmd);

				if (s != null)
					c.Add(s);
			}
			else if (cmd == 9)
			{
				foreach (var s in c)
				{
					s.Draw();
				}
			}

		}
	}
}



