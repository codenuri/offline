// 189page
#include <iostream>

class Point
{
	int x;
	int y;
public:
	Point(int x = 0, int y = 0) : x(x), y(y) {}
};

int main()
{
	Point p(1, 2);

	std::cout << p ;
					
					
					
}


