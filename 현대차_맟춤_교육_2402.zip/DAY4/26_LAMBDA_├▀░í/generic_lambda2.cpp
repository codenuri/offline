#include <iostream>

class CompilerGeneratedName 
{
public:
	template<typename T1, typename T2>
	auto operator()(auto a, auto b) const 
	{
		return a + b;
	}
};

int main()
{
//	auto add = [](auto a, auto b) { return a + b;};

	auto add = CompilerGeneratedName();
}

