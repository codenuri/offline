#include <iostream>



int main()
{
	vector v(4);

	v[0] = 10;
}