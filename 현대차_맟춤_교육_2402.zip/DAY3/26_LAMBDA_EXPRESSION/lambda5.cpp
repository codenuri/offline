#include <iostream>

int main()
{
	int v1 = 10, v2 = 10;

	auto f1 = [](int a) { return a + v1 + v2; }; 


}





