﻿// 1_초기화8 - 62page
#include <iostream>
#include <initializer_list> // 핵심

void foo(std::initializer_list<int> e)
{
}
int main()
{

	std::initializer_list<int> e = { 1,2,3,4,5 };
}


