﻿// 1_후위반환타입1.cpp - 교재 73 page

int square(int a)
{
	return a * a;
}

int main()
{
	square(3);
}
