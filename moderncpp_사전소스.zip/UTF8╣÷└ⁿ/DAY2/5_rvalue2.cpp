﻿// 핵심 : rvalue, lvalue 의 개념은 
//       변수(객체)에 부여되는 개념이 아닌
//       표현식(expression) 에 부여 되는 개념
// expression : 한개의 값을 나타내는 코드 집합

int main()
{
	int n = 0;
}
