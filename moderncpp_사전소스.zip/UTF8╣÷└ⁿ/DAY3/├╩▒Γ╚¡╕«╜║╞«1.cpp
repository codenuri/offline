﻿#include <string>
#include <iostream>

int main()
{
	std::string s1 = "abcd";

	std::string s2;
	s2 = "abcd";
}
