﻿//8_nullptr3
#include <iostream>

int main()
{
	// literal 과 타입
	3;
	3.4;
	"hello";
	false;
	nullptr;
}



