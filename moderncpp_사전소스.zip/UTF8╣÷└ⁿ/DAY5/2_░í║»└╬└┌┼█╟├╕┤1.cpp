﻿// 7_가변인자템플릿1 - 225 page

// 가변인자 함수 템플릿
template<typename ... T> void foo(T ... a) {}

// 가변인자 클래스 템플릿
template<typename ... T> class xtuple 
{
};
int main()
{

}
