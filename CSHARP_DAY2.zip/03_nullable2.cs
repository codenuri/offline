﻿string s = null;
int?   n = null;

