using static System.Console;

int  a1 = 10;
int? n1 = 10;

int? n2 = a1;
int? a2 = n1;





