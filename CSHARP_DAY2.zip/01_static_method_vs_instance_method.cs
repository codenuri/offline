﻿
int n = 10; // int : 타입
            // n   : 변수(객체)

// instance method : 
// static   method :

int n1 = 10;
int n2 = 20;

string s1 = n1.ToString();
string s2 = n2.ToString();


string s = "10";
int ret1 = int.Parse(s);