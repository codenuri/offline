﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DATABINDING1
{
    /// <summary>
    /// Ex4Window.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Ex4Window : Window
    {
        public ObservableCollection<Person> st = new ObservableCollection<Person>();

        public Ex4Window()
        {
            InitializeComponent();

            st.Add(new Person { Name = "kim1", Address = "jeju1" });
            st.Add(new Person { Name = "kim2", Address = "jeju2" });
            st.Add(new Person { Name = "kim3", Address = "jeju3" });
            st.Add(new Person { Name = "kim4", Address = "jeju4" });

            dataGrid.ItemsSource = st;
        }
    }
}
