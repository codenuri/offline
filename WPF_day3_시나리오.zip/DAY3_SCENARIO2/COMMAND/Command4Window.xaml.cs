﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace COMMAND
{
    public class ActionCommand3 : ICommand
    {

        public event EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }

            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }




        public TextBox txtBox = null;
          
              
        public bool CanExecute(object parameter)
        {
            Console.WriteLine("CanExecute");

            if (txtBox == null)
                txtBox = ((Command4Window)Application.Current.MainWindow).txtBox;

            return !string.IsNullOrEmpty(txtBox.Text);
        }


        public void Execute(object parameter)
        {
            MessageBox.Show(txtBox?.Text);
        }
    }

    static class MyCommand3
    {
        public static ActionCommand3 cmdAction = new ActionCommand3();
    }

    public partial class Command4Window : Window
    {
        public Command4Window()
        {
            InitializeComponent();
        }
    }
}
