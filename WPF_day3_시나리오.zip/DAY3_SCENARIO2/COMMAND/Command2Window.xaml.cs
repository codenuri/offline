﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace COMMAND
{
    public class ActionCommand : ICommand
    {
        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            //return true;
            return false;
        }

        public void Execute(object parameter)
        {
            MessageBox.Show("ActionCommand");
        }
    }

    static class MyCommand
    {
        public static ActionCommand cmdAction = new ActionCommand();
    }



    public partial class Command2Window : Window
    {
        // 멤버로 먼저 만들어 둘것
//        public static ActionCommand cmdAction = new ActionCommand();

        public Command2Window()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
