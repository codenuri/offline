﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BIND2
{


    /// <summary>
    /// Step2.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Step2 : Window
    {
        //public List<People> st = new List<People>();
        public ObservableCollection<People> st = new ObservableCollection<People>();

        public Step2()
        {
            InitializeComponent();

            st.Add(new People { Name = "kim1", Address = "seoul1" });
            st.Add(new People { Name = "kim2", Address = "seoul2" });
            st.Add(new People { Name = "kim3", Address = "seoul3" });
            st.Add(new People { Name = "kim4", Address = "seoul4" });
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            listPeople.ItemsSource = st;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            listPeople.ItemsSource = st;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            st.Add(new People { Name = "kim3", Address = "seoul3" });
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            st[0].Name = "XXXX";
        }
    }
}
