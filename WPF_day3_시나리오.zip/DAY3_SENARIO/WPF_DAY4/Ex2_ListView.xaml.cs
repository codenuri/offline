﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_DAY4
{
    /// <summary>
    /// Ex2_ListView.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Ex2_ListView : Window
    {
        public Ex2_ListView()
        {
            InitializeComponent();
        }
    }
}
