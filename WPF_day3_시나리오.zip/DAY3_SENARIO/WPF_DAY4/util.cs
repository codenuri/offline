﻿using System;

class Util
{
    // ShowHierachy 메소드 복사해 오세요
    public static void ShowHierachy(object obj)
    {
        Type t = obj.GetType();

        while (true)
        {
            Console.Write($"{t.Name}");

            if (t == typeof(object)) break;

            Console.Write(" => ");

            t = t.BaseType;
        }
        Console.WriteLine("");
    }
}