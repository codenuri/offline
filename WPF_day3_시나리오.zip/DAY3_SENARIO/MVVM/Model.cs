﻿using System;
using System.ComponentModel;

namespace MVVM
{
    public class Model
    {
        public Model() { Data = 0; }
        public int Data
        {
            get => _data;
            set
            {
                if (_data != value)
                {
                    _data = value;
                    Console.WriteLine(this);
                }
            }
        }
        public int _data = 0;

        public override string ToString() => $"Data:{Data}";
    }
}
}