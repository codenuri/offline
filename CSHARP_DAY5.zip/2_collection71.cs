﻿using System;
using System.Collections;
using System.Collections.Generic;
using static System.Console;

// 주제 6. 사용자 정의 타입과 해쉬, Equals(), GetHashCode()

class People
{
    public string name;
    public int age;

    public People(string n, int a) { name = n; age = a; }

    // 참조가 아닌 값에 의한 상등성 조사
    public override bool Equals(object obj)
    {
        People p = obj as People;

        return name == p.name && age == p.age;
    }

    // 핵심. 사용자 정의 타입을 hash 에 넣을때는
    // 아래 함수를 재정의 하는 것이 좋습니다.
    // 값에 의한 검색을 하기위해
    public override int GetHashCode()
    {
        // C#은 이미 문자열 해쉬에 정수형 해쉬를 구할수 있습니다.
        return name.GetHashCode() + age.GetHashCode();
    }

}

class Program
{
    public static void Main()
    {
        HashSet<People> hs = new HashSet<People>();

        People p1 = new People("Kim", 20);
        People p2 = new People("Lee", 30);
        People p3 = new People("Kim", 20);

        bool b = p1.Equals(p3); // true

        WriteLine(p1.GetHashCode());
        WriteLine(p3.GetHashCode());


        hs.Add(p1);
        hs.Add(p2);

        WriteLine(hs.Contains(p3)); // false 특정 사람 검색.

        
    }
}