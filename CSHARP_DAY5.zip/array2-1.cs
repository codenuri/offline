﻿using static System.Console;

// #2. 배열과 타입
void print_type(object obj)
{
    Type t1 = obj.GetType();
    Type t2 = t1.BaseType!;
    Type t3 = t2.BaseType!;

    WriteLine($"{t1.Name} -> {t2.Name} -> {t3.Name}");
}

int[] arr1 = { 1, 2, 3 };
int[,] arr2 = { { 1, 2 }, { 3, 4 } };
int[][] arr3 = new int[3][];

print_type(arr1);
print_type(arr2);
print_type(arr3);