﻿using System;
using System.Collections;
using System.Collections.Generic;
using static System.Console;

// 주제 7. Dictionary
// 정렬된 dictionary
// SortedDictionary : RedBlack Tree
// SortedList  : 배열 2개

class Program
{
    public static void Main()
    {
        SortedDictionary<string, string> sd = SortedDictionary<string, string>();
        ss.Add("mon", "월요일");

        SortedList<string, string> sl = new SortedList<string, string>();
        sl.Add("mon", "월요일");


    }
}