﻿using static System.Console;

int[] arr = { 1, 2, 3, 4, 5 };

WriteLine($"{arr.Length}")
WriteLine($"{arr.LongLength}")
WriteLine($"{arr.Rank}")
WriteLine($"{arr.IsReadOnly}")
WriteLine($"{arr.IsFixedSize}")
WriteLine($"{arr.IsSynchronized}")

/*
Int32 Length
Int64 LongLength
Int32 Rank
System.Object SyncRoot
Boolean IsReadOnly
Boolean IsFixedSize
Boolean IsSynchronized
*/