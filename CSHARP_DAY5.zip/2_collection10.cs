﻿using System;
using System.Collections;
using System.Collections.Generic;
using static System.Console;

// 주제 1. Generic vs Non Generic

class Program
{
    public static void Main()
    {
        ArrayList col1 = new ArrayList(); // object 보관

        col1.Add(10);
        //col1.Add("hello");// 에러가 없다.
                            // type 안정성이 떨어진다.
        col1.Add(30); // 스택에 있던 30이 
                    // 힙에 복사본을 만들어서 놓인다. - Boxing
                    // 성능저하.

        int n =(int)col1[0]; // 꺼낼때는 반드시 캐스팅이 필요하다

        // C# 2.0 부터 Generic(template) 문법 지원
        List<int> col2 = new List<int>();

        col2.Add(10);
        col2.Add("hello"); // 1.  error. 타입 안정성이 뛰어나다.

        int n2 = col2[0]; //  2. ok. 캐스팅이 필요 없다.

                            // 3. Boxing/Unboxing 이 없다.
                            //    성능이 좋다.
                            


    }
}

