﻿using System.Reflection;
using static System.Console;

// #6. Array Static method
int[] arr = { 1, 2, 3, 4, 5 };

//-----------------------
Array.AsReadOnly();
Array.BinarySearch();
Array.Clear();
Array.ConstrainedCopy();
Array.ConvertAll();
Array.Copy();
Array.CreateInstance();
Array.Empty();
Array.Equals();
Array.Exists();
Array.Fill();
Array.Find();
Array.FindAll();
Array.FindIndex();
Array.FindLast();
Array.FindLastIndex();
Array.ForEach();
Array.IndexOf();
Array.LastIndexOf();
Array.ReferenceEquals();
Array.Resize();
Array.Reverse();
Array.Sort();
Array.TrueForAll();


// Array.Sort(arr);

Type t = arr.GetType();

var mis = t.GetMethods(BindingFlags.Public | BindingFlags.Static | BindingFlags.FlattenHierarchy);


foreach (var mi in mis)
{
    WriteLine(mi.Name);
}

// Equals

/*
AsReadOnly
BinarySearch
Clear
ConstrainedCopy
ConvertAll
Copy
CreateInstance
Empty

Exists
Fill
Find
FindAll
FindIndex
FindLast
FindLastIndex
ForEach
IndexOf
LastIndexOf
ReferenceEquals
Resize
Reverse
Sort
TrueForAll



*/