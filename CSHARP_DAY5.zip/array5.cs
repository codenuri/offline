﻿using System.Reflection;
using static System.Console;

// #5. array method
// => 총정리!
int[] arr = { 1, 2, 3, 4, 5 };

// 4 method from object
arr.GetType();
arr.ToString();
arr.GetHashCode();
arr.Equals();

// 10 method from Array
arr.GetEnumerator();
arr.SetValue();
arr.GetValue();
arr.Initialize();
arr.Clone();
arr.CopyTo();
arr.GetLength();
arr.GetLongLength();
arr.GetLowerBound();
arr.GetUpperBound();



